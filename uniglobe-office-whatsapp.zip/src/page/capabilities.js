// Capability detection for the WhatsApp Web adapter. Classic script (MAIN
// world). An operation is reported as supported only when every internal
// function it needs actually resolved in the running WhatsApp Web build —
// the adapter never pretends an operation works.
(function (root) {
  "use strict";

  // Internal module names this adapter tries to load via window.require.
  // They are not a public API and can change with any WhatsApp Web release.
  var MODULES = {
    collections: "WAWebCollections",
    conn: "WAWebConnModel",
    socket: "WAWebSocketModel",
    meUser: "WAWebUserPrefsMeUser",
    msgKey: "WAWebMsgKey",
    sendMsg: "WAWebSendMsgChatAction",
    widFactory: "WAWebWidFactory",
    findChat: "WAWebFindChatAction",
    download: "WAWebDownloadManager",
    loadMsgs: "WAWebChatLoadMessages",
    seen: "WAWebUpdateUnreadChatAction",
    reaction: "WAWebSendReactionMsgAction",
    apiContact: "WAWebApiContact",
    cmd: "WAWebCmd",
    edit: "WAWebSendMessageEditAction",
    opaqueData: "WAWebMediaOpaqueData",
    mediaPrep: "WAWebPrepRawMedia"
  };

  function fn(obj, name) {
    return Boolean(obj) && typeof obj[name] === "function";
  }

  // m = resolved handles (see whatsapp-adapter.js resolveModules()).
  function computeCapabilities(m) {
    m = m || {};
    var identity = fn(m.MeUser, "getMaybeMeUser") || fn(m.MeUser, "getMaybeMePnUser");
    var listChats = fn(m.Chat, "getModelsArray");
    var subscribe = fn(m.Msg, "on");
    var fetchMessages = listChats && fn(m.LoadMsgs, "loadEarlierMsgs");
    var resolveChat = fn(m.Chat, "get") || (fn(m.WidFactory, "createWid") && fn(m.FindChat, "findOrCreateLatestChat"));
    var sendText = identity && resolveChat && fn(m.MsgKey, "newId") && typeof m.MsgKey === "function" && fn(m.SendMsg, "addAndSendMsgToChat");
    return {
      identity: identity,
      listChats: listChats,
      fetchMessages: fetchMessages,
      subscribe: subscribe,
      resolveContact: fn(m.ApiContact, "getPhoneNumber"),
      sendText: sendText,
      // Quoting additionally needs the quoted model to expose msgContextInfo;
      // that is re-checked per message at send time.
      sendQuotedReply: sendText && fn(m.Msg, "get"),
      sendMedia: resolveChat && fn(m.OpaqueData, "createFromData") && fn(m.MediaPrep, "prepRawMedia"),
      fetchMedia: fn(m.Msg, "get") && fn(m.Download, "downloadAndMaybeDecrypt"),
      openChat: fn(m.Cmd, "openChatBottom") || fn(m.Cmd, "openChatAt"),
      markRead: fn(m.Seen, "sendSeen"),
      edit: fn(m.Edit, "sendMessageEdit"),
      react: fn(m.Reaction, "sendReactionToMsg"),
      revoke: fn(m.Cmd, "sendRevokeMsgs")
    };
  }

  root.UGOW_CAPS = { MODULES: MODULES, computeCapabilities: computeCapabilities };
})(typeof globalThis !== "undefined" ? globalThis : window);
