// UniGlobe WhatsApp Web adapter. Classic script injected into the page's MAIN
// world by the manifest (packaged, never downloaded). It is ORIGINAL code that
// talks to the already-loaded WhatsApp Web client through its internal module
// registry (window.require). Those modules are not a stable public API: every
// handle is resolved defensively, capabilities are reported honestly, and any
// operation whose modules did not resolve fails with CAPABILITY_UNAVAILABLE.
//
// Security notes:
// - This script shares the page world with WhatsApp's own scripts. It never
//   receives CRM tokens, API URLs or student CRM data — only chat keys,
//   message text/media to send, and RPC method names from the bridge.
// - The channel nonce (read from a DOM attribute set by the isolated bridge)
//   only prevents accidental cross-talk; any page script can read it. The
//   service worker and the CRM server re-validate everything this script says.
(function () {
  "use strict";
  if (window.__ugowAdapterLoaded) return;
  window.__ugowAdapterLoaded = true;

  var ADAPTER_VERSION = "ugow-wa-adapter/1.0.6";
  var MAP = window.UGOW_MAPPING;
  var CAPS = window.UGOW_CAPS;
  var MAX_MEDIA_BYTES = 32 * 1024 * 1024;
  var CHUNK_BYTES = 512 * 1024;

  var mods = null;
  var subscribed = false;
  var capture = true; // the service worker may set a secondary tab passive
  var outbox = [];
  var flushTimer = null;
  var lastIdentityJson = "";
  var prepared = new Map(); // token -> { key, chat, providerMessageId }
  var mediaBuffers = new Map(); // token -> { bytes, mimeType } (fetched or staged)
  var officeCall = null;

  // ---- channel -------------------------------------------------------------
  function nonce() {
    return document.documentElement && document.documentElement.getAttribute("data-ugow-channel");
  }

  function post(kind, payload) {
    var n = nonce();
    if (!n) return false;
    var message = Object.assign({ source: "ugow-page", nonce: n, kind: kind }, payload);
    window.postMessage(message, window.location.origin);
    return true;
  }

  function queueEvents(events) {
    if (!capture || !events || !events.length) return;
    Array.prototype.push.apply(outbox, events);
    if (!flushTimer) flushTimer = setTimeout(flushEvents, 250);
  }

  function flushEvents() {
    flushTimer = null;
    if (!outbox.length) return;
    if (!nonce()) { flushTimer = setTimeout(flushEvents, 500); return; }
    while (outbox.length) post("events", { events: outbox.splice(0, 50) });
  }

  // ---- module resolution -----------------------------------------------------
  function load(name) {
    try {
      if (typeof window.require !== "function") return null;
      return window.require(name) || null;
    } catch (error) {
      return null;
    }
  }

  function unwrap(m) {
    return m && m.default ? m.default : m;
  }

  function resolveModules() {
    var N = CAPS.MODULES;
    var collections = load(N.collections);
    var raw = {};
    Object.keys(N).forEach(function (key) { raw[key] = load(N[key]); });
    return {
      raw: raw,
      Chat: collections && collections.Chat || null,
      Msg: collections && collections.Msg || null,
      Contact: collections && collections.Contact || null,
      Conn: raw.conn && raw.conn.Conn || null,
      Socket: raw.socket && raw.socket.Socket || null,
      MeUser: raw.meUser,
      MsgKey: unwrap(raw.msgKey),
      SendMsg: raw.sendMsg,
      WidFactory: raw.widFactory,
      FindChat: raw.findChat,
      Download: raw.download && raw.download.downloadManager || null,
      LoadMsgs: raw.loadMsgs,
      Seen: raw.seen,
      Reaction: raw.reaction,
      ApiContact: raw.apiContact,
      Cmd: raw.cmd && raw.cmd.Cmd || null,
      Edit: raw.edit,
      OpaqueData: unwrap(raw.opaqueData),
      MediaPrep: raw.mediaPrep
    };
  }

  function m() {
    if (!mods || !mods.Msg || !mods.MeUser) mods = resolveModules();
    return mods;
  }

  function capabilities() {
    return CAPS.computeCapabilities(m());
  }

  function selfTest() {
    var resolved = m();
    var modules = {};
    Object.keys(CAPS.MODULES).forEach(function (key) { modules[CAPS.MODULES[key]] = Boolean(resolved.raw[key]); });
    return { adapterVersion: ADAPTER_VERSION, requireAvailable: typeof window.require === "function", modules: modules, capabilities: capabilities() };
  }

  function fail(code, message) {
    var error = new Error(message || code);
    error.code = code;
    throw error;
  }

  function need(capability) {
    if (!capabilities()[capability]) fail("CAPABILITY_UNAVAILABLE", capability + " is not available in this WhatsApp Web version");
  }

  // ---- identity ----------------------------------------------------------------
  function loggedOutDom() {
    return Boolean(document.querySelector("[data-ref] canvas, canvas[aria-label*='scan' i], [data-testid='qrcode']"));
  }

  function meWid() {
    var mu = m().MeUser;
    if (!mu) return null;
    try {
      return (typeof mu.getMaybeMePnUser === "function" && mu.getMaybeMePnUser()) ||
        (typeof mu.getMaybeMeUser === "function" && mu.getMaybeMeUser()) || null;
    } catch (error) { return null; }
  }

  function meLidWid() {
    var mu = m().MeUser;
    try { return mu && typeof mu.getMaybeMeLidUser === "function" ? mu.getMaybeMeLidUser() : null; } catch (error) { return null; }
  }

  function identity() {
    if (typeof window.require !== "function") {
      return { state: loggedOutDom() ? "LOGGED_OUT" : "LOADING", adapterVersion: ADAPTER_VERSION };
    }
    var resolved = m();
    var socketState = resolved.Socket && typeof resolved.Socket.state === "string" ? resolved.Socket.state : null;
    if (socketState && /UNPAIRED|UNLAUNCHED|DEPRECATED_VERSION/.test(socketState)) {
      return { state: "LOGGED_OUT", socketState: socketState, adapterVersion: ADAPTER_VERSION };
    }
    var me = meWid();
    if (!me) return { state: loggedOutDom() ? "LOGGED_OUT" : "LOADING", socketState: socketState, adapterVersion: ADAPTER_VERSION };
    var user = String(me.user || "");
    var phone = /^\d{7,15}$/.test(user) ? "+" + user : null;
    var caps = capabilities();
    if (!caps.listChats || !caps.subscribe || !phone) {
      return {
        state: "ADAPTER_ERROR",
        observedPhoneE164: phone,
        socketState: socketState,
        adapterVersion: ADAPTER_VERSION,
        adapterError: "Required WhatsApp Web modules did not resolve (chats/messages/identity)"
      };
    }
    return { state: "CONNECTED", observedPhoneE164: phone, socketState: socketState, adapterVersion: ADAPTER_VERSION, capabilities: caps };
  }

  function publishIdentity(force) {
    var id = identity();
    var json = JSON.stringify(id);
    if (force || json !== lastIdentityJson) {
      lastIdentityJson = json;
      post("identity", { identity: id });
    }
    if (id.state === "CONNECTED" && !subscribed) subscribe();
  }

  // ---- chats and messages -------------------------------------------------------
  function chatKeyOf(chat) {
    return chat && MAP.serializeWid(chat.id);
  }

  function chatName(chat) {
    try {
      return chat.name || chat.formattedTitle || (chat.contact && (chat.contact.name || chat.contact.pushname)) || null;
    } catch (error) { return null; }
  }

  // Phone for an opaque @lid chat — only when the client itself exposes it.
  async function lidPhone(chatKey) {
    if (!/@lid$/.test(chatKey)) return null;
    var api = m().ApiContact;
    var wf = m().WidFactory;
    if (!api || typeof api.getPhoneNumber !== "function" || !wf || typeof wf.createWid !== "function") return null;
    try {
      // WhatsApp Web versions differ: this API may return a Wid immediately
      // or a Promise. Never infer a phone from the opaque LID itself.
      var result = await api.getPhoneNumber(wf.createWid(chatKey));
      var pn = result && (result.pn || result.phoneNumber || result.wid || result);
      var fromWid = MAP.phoneFromChatKey(MAP.serializeWid(pn));
      if (fromWid) return fromWid;
      var user = pn && String(pn.user || "");
      return /^\d{7,15}$/.test(user) ? "+" + user : null;
    } catch (error) { return null; }
  }

  async function peerContext(chat, chatKey) {
    return { phoneE164: MAP.phoneFromChatKey(chatKey) || await lidPhone(chatKey), displayName: chatName(chat) };
  }

  function findChatModel(chatKey) {
    var resolved = m();
    return resolved.Chat && typeof resolved.Chat.get === "function" ? resolved.Chat.get(chatKey) : null;
  }

  async function getChat(chatKey, create) {
    if (!MAP.isDirectChatKey(chatKey)) fail("NOT_DIRECT_CHAT", "Only one-to-one chats are supported");
    var chat = findChatModel(chatKey);
    if (chat || !create) return chat || null;
    var resolved = m();
    if (!resolved.WidFactory || !resolved.FindChat) return null;
    var result = await resolved.FindChat.findOrCreateLatestChat(resolved.WidFactory.createWid(chatKey));
    return result && (result.chat || result) || null;
  }

  function quotedIdFor(msg) {
    try {
      var a = msg.attributes || msg;
      var stanza = a.quotedStanzaID;
      if (!stanza) return null;
      var remote = MAP.serializeWid(a.quotedRemoteJid) || MAP.serializeWid(a.id && a.id.remote);
      var Msg = m().Msg;
      if (!remote || !Msg) return null;
      var candidates = ["true_" + remote + "_" + stanza, "false_" + remote + "_" + stanza];
      for (var i = 0; i < candidates.length; i += 1) if (Msg.get(candidates[i])) return candidates[i];
      return null; // unknown direction: do not guess a key
    } catch (error) { return null; }
  }

  function snapshot(msg) {
    return MAP.readMsg(msg, { quotedId: quotedIdFor(msg) });
  }

  async function eventsForMsg(msg, mode) {
    var snap = snapshot(msg);
    if (!snap || !MAP.isDirectChatKey(snap.chatKey)) return [];
    var ctx = Object.assign({ mode: mode, observedAt: new Date().toISOString() }, await peerContext(findChatModel(snap.chatKey), snap.chatKey));
    var events = MAP.buildMessageEvents(snap, ctx);
    if (snap.editTimestampMs) {
      var edit = MAP.buildEditEvent(snap, ctx);
      if (edit) events.push(edit);
    }
    if (ctx.phoneE164 && /@lid$/.test(snap.chatKey)) {
      var mapping = MAP.buildMappingEvent(snap.chatKey, ctx.phoneE164, ctx.displayName);
      if (mapping) events.push(mapping);
    }
    return events;
  }

  async function listDirectChats(params) {
    need("listChats");
    var offset = Number(params && params.cursor) || 0;
    var limit = Math.min(Number(params && params.limit) || 200, 500);
    var all = m().Chat.getModelsArray()
      .filter(function (chat) { return MAP.isDirectChatKey(chatKeyOf(chat)); })
      .sort(function (a, b) { return (Number(b.t) || 0) - (Number(a.t) || 0); });
    var page = await Promise.all(all.slice(offset, offset + limit).map(async function (chat) {
      var key = chatKeyOf(chat);
      var ctx = await peerContext(chat, key);
      return { chatKey: key, name: ctx.displayName, phoneE164: ctx.phoneE164, unreadCount: Number(chat.unreadCount) || 0, lastMessageAtMs: (Number(chat.t) || 0) * 1000 };
    }));
    return { chats: page, cursor: offset + limit < all.length ? String(offset + limit) : null, total: all.length };
  }

  function chatMessages(chat) {
    var msgs = chat && chat.msgs;
    if (!msgs) return [];
    if (typeof msgs.getModelsArray === "function") return msgs.getModelsArray();
    return Array.isArray(msgs.models) ? msgs.models : [];
  }

  // Loads earlier messages until sinceMs is covered, the client reports no
  // more history, or maxLoads is spent (then `more` = true and the caller
  // continues later). Returns only what the client exposed.
  async function fetchMessages(params) {
    need("fetchMessages");
    var chat = await getChat(params.chatKey, false);
    if (!chat) return { events: [], reachedStart: false, more: false, coveredFrom: null, coveredTo: null, missing: true };
    var sinceMs = Number(params.sinceMs) || 0;
    var historyBeforeMs = Number(params.historyBeforeMs) || 0;
    var maxLoads = Math.min(Number(params.maxLoads) || 5, 20);
    var reachedStart = false;
    var loads = 0;
    var oldest = function () {
      var list = chatMessages(chat);
      var min = Infinity;
      list.forEach(function (msg) { var t = Number((msg.attributes || msg).t); if (t && t < min) min = t; });
      return min === Infinity ? null : min * 1000;
    };
    while (loads < maxLoads) {
      var current = oldest();
      if (current !== null && current <= sinceMs) break;
      var before = chatMessages(chat).length;
      var loaded = await m().LoadMsgs.loadEarlierMsgs(chat);
      loads += 1;
      var after = chatMessages(chat).length;
      if ((!loaded || (Array.isArray(loaded) && loaded.length === 0)) && after === before) { reachedStart = true; break; }
      if (after === before) { reachedStart = true; break; }
    }
    var events = [];
    var coveredFrom = null;
    var nowIso = new Date().toISOString();
    for (var msg of chatMessages(chat)) {
      var t = Number((msg.attributes || msg).t) * 1000;
      if (!t || t < sinceMs) continue;
      if (coveredFrom === null || t < coveredFrom) coveredFrom = t;
      var mode = t < historyBeforeMs ? "HISTORY" : "RECONCILE";
      var evs = await eventsForMsg(msg, mode);
      var snap = snapshot(msg);
      if (snap && snap.fromMe && snap.ack !== null && snap.ack > 0) {
        var ack = MAP.buildAckEvent(snap, { mode: mode, observedAt: nowIso });
        if (ack) evs.push(ack);
      }
      Array.prototype.push.apply(events, evs);
    }
    var oldestMs = oldest();
    return {
      events: events,
      reachedStart: reachedStart,
      more: !reachedStart && oldestMs !== null && oldestMs > sinceMs,
      coveredFrom: reachedStart && oldestMs !== null ? new Date(oldestMs).toISOString() : (coveredFrom ? new Date(Math.max(coveredFrom, sinceMs)).toISOString() : null),
      coveredTo: nowIso
    };
  }

  async function resolveContact(params) {
    var chatKey = params && params.chatKey;
    if (!MAP.isDirectChatKey(chatKey)) fail("NOT_DIRECT_CHAT");
    var ctx = await peerContext(findChatModel(chatKey), chatKey);
    return { chatKey: chatKey, phoneE164: ctx.phoneE164, displayName: ctx.displayName };
  }

  // ---- live subscription ----------------------------------------------------------
  function subscribe() {
    var resolved = m();
    if (subscribed || !resolved.Msg || typeof resolved.Msg.on !== "function") return;
    subscribed = true;
    resolved.Msg.on("add", function (msg) {
      // Messages added because history was loaded are handled by fetchMessages.
      var raw = msg && (msg.attributes || msg);
      var recent = raw && Number(raw.t) > 0 && Math.abs(Date.now() - Number(raw.t) * 1000) < 2 * 60 * 1000;
      if (!msg || !(msg.isNewMsg || raw.isNewMsg || recent)) return;
      eventsForMsg(msg, "LIVE").then(queueEvents).catch(function () {});
    });
    resolved.Msg.on("change:ack", function (msg) {
      var ev = MAP.buildAckEvent(snapshot(msg), { mode: "LIVE", observedAt: new Date().toISOString() });
      if (ev) queueEvents([ev]);
    });
    resolved.Msg.on("change:type", function (msg) {
      var snap = snapshot(msg);
      if (!snap) return;
      if (snap.type === "revoked") {
        var ev = MAP.buildRevokeEvent(snap, { mode: "LIVE" });
        if (ev) queueEvents([ev]);
      } else {
        // e.g. ciphertext that has now been decrypted.
        eventsForMsg(msg, "LIVE").then(queueEvents).catch(function () {});
      }
    });
    var onEdit = function (msg) {
      var snap = snapshot(msg);
      var ev = snap && MAP.buildEditEvent(snap, { mode: "LIVE" });
      if (ev) queueEvents([ev]);
    };
    resolved.Msg.on("change:latestEditSenderTimestampMs", onEdit);
    if (resolved.Chat && typeof resolved.Chat.on === "function") {
      resolved.Chat.on("change:active", function (chat, active) {
        if (active) post("active-chat", { chatKey: chatKeyOf(chat) || null, direct: MAP.isDirectChatKey(chatKeyOf(chat)) });
      });
    }
    publishActiveChat();
  }

  function publishActiveChat() {
    var resolved = m();
    if (!resolved.Chat || typeof resolved.Chat.getModelsArray !== "function") return;
    var active = resolved.Chat.getModelsArray().find(function (chat) { return chat.active; });
    var key = active ? chatKeyOf(active) : null;
    post("active-chat", { chatKey: key, direct: MAP.isDirectChatKey(key) });
  }

  // ---- sending --------------------------------------------------------------------
  // Step 1 of the command protocol: create the message key WITHOUT sending, so
  // the service worker can journal the provider id before anything leaves.
  async function prepareSend(params) {
    need("sendText");
    var chat = await getChat(params.chatKey, true);
    if (!chat) fail("NOT_SENT_CHAT_UNAVAILABLE", "Chat could not be opened for this number");
    var resolved = m();
    var isLid = chat.id && chat.id.server === "lid";
    var from = (isLid && meLidWid()) || meWid();
    if (!from) fail("NOT_SENT_LOGGED_OUT", "WhatsApp Web is not signed in");
    var newId = await resolved.MsgKey.newId();
    var key = new resolved.MsgKey({ from: from, to: chat.id, id: newId, selfDir: "out" });
    var providerMessageId = MAP.serializeKey(key);
    if (!providerMessageId) fail("NOT_SENT_KEY_UNAVAILABLE", "Could not create a message id");
    var token = String(Math.random()).slice(2) + Date.now();
    prepared.set(token, { key: key, chat: chat, from: from, providerMessageId: providerMessageId });
    return { token: token, providerMessageId: providerMessageId };
  }

  async function settle(result) {
    // addAndSendMsgToChat returns a promise or an array of promises depending on version.
    if (Array.isArray(result)) {
      for (var i = 0; i < result.length; i += 1) await result[i];
    } else {
      await result;
    }
  }

  async function commitSend(params) {
    var entry = prepared.get(params.token);
    // The page reloaded between prepare and commit: nothing was sent.
    if (!entry) fail("NOT_SENT_PREPARE_LOST", "Send preparation expired");
    prepared.delete(params.token);
    var text = String(params.text || "");
    if (!text.trim()) fail("NOT_SENT_EMPTY", "Message text is empty");
    var message = {
      id: entry.key, ack: 0, body: text, type: "chat", from: entry.from, to: entry.chat.id,
      local: true, self: "out", t: Math.floor(Date.now() / 1000), isNewMsg: true
    };
    if (params.quotedProviderMessageId) {
      if (!capabilities().sendQuotedReply) fail("NOT_SENT_QUOTE_UNAVAILABLE", "Quoted replies are not available");
      var quoted = m().Msg.get(params.quotedProviderMessageId);
      if (!quoted || typeof quoted.msgContextInfo !== "function") fail("NOT_SENT_QUOTE_UNAVAILABLE", "The quoted message is not available in WhatsApp Web");
      Object.assign(message, quoted.msgContextInfo(entry.chat.id));
    }
    // From here on the outcome is uncertain if anything throws.
    try {
      await settle(m().SendMsg.addAndSendMsgToChat(entry.chat, message));
    } catch (error) {
      fail("SEND_UNCERTAIN", error && error.message ? String(error.message).slice(0, 200) : "send threw");
    }
    return { providerMessageId: entry.providerMessageId };
  }

  function messageExists(params) {
    var Msg = m().Msg;
    if (!Msg || typeof Msg.get !== "function") fail("CAPABILITY_UNAVAILABLE", "message lookup unavailable");
    var msg = Msg.get(params.providerMessageId);
    if (!msg) return { exists: false };
    var a = msg.attributes || msg;
    return { exists: true, ack: typeof a.ack === "number" ? a.ack : null };
  }

  function b64FromBytes(bytes) {
    var out = "";
    for (var i = 0; i < bytes.length; i += 0x8000) out += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(out);
  }

  function bytesFromB64(b64) {
    var bin = atob(b64);
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  function stageMedia(params) {
    var token = params.token;
    var entry = mediaBuffers.get(token) || { parts: [], size: 0, mimeType: params.mimeType || "application/octet-stream" };
    var chunk = bytesFromB64(String(params.chunk || ""));
    entry.size += chunk.length;
    if (entry.size > MAX_MEDIA_BYTES) { mediaBuffers.delete(token); fail("NOT_SENT_TOO_LARGE"); }
    entry.parts.push(chunk);
    mediaBuffers.set(token, entry);
    return { received: entry.size };
  }

  // Media send: WhatsApp Web's media pipeline does not accept a pre-generated
  // key, so the new message id is found afterwards by diffing the chat. If that
  // is ambiguous the id is reported as null (the CRM shows the send as
  // accepted but cannot link the echo automatically).
  async function sendMedia(params) {
    need("sendMedia");
    var staged = mediaBuffers.get(params.token);
    if (!staged) fail("NOT_SENT_MEDIA_MISSING", "Media was not staged");
    mediaBuffers.delete(params.token);
    var chat = await getChat(params.chatKey, true);
    if (!chat) fail("NOT_SENT_CHAT_UNAVAILABLE");
    var resolved = m();
    var blob = new Blob(staged.parts, { type: params.mimeType || staged.mimeType });
    var file = new File([blob], params.fileName || "file", { type: blob.type });
    var beforeIds = {};
    chatMessages(chat).forEach(function (msg) { var id = MAP.serializeKey((msg.attributes || msg).id); if (id) beforeIds[id] = 1; });
    try {
      var opaque = await resolved.OpaqueData.createFromData(file, file.type);
      var prep = resolved.MediaPrep.prepRawMedia(opaque, { asDocument: params.kind === "document", isPtt: params.asVoice === true });
      if (prep && typeof prep.waitForPrep === "function") await prep.waitForPrep();
      if (!prep || typeof prep.sendToChat !== "function") fail("NOT_SENT_MEDIA_PIPELINE", "media pipeline unavailable");
      var result = prep.sendToChat(chat, { caption: params.caption || undefined });
      await settle(result);
    } catch (error) {
      if (error && /^NOT_SENT/.test(error.code || "")) throw error;
      fail("SEND_UNCERTAIN", error && error.message ? String(error.message).slice(0, 200) : "media send threw");
    }
    var fresh = chatMessages(chat)
      .map(function (msg) { return MAP.readMsg(msg); })
      .filter(function (snap) { return snap && snap.fromMe && snap.id && !beforeIds[snap.id] && snap.type !== "chat"; });
    return { providerMessageId: fresh.length === 1 ? fresh[0].id : null };
  }

  async function fetchMedia(params) {
    need("fetchMedia");
    var maxBytes = Math.min(Number(params.maxBytes) || MAX_MEDIA_BYTES, MAX_MEDIA_BYTES);
    var msg = m().Msg.get(params.providerMessageId);
    if (!msg) return { unavailable: "NOT_FOUND" };
    var a = msg.attributes || msg;
    if (a.isViewOnce) return { unavailable: "VIEW_ONCE" };
    if (!a.directPath || !a.mediaKey) return { unavailable: "NO_MEDIA_PATH" };
    if (Number(a.size) > maxBytes) return { unavailable: "TOO_LARGE" };
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 120000);
    try {
      var buffer = await m().Download.downloadAndMaybeDecrypt({
        directPath: a.directPath, encFilehash: a.encFilehash, filehash: a.filehash,
        mediaKey: a.mediaKey, mediaKeyTimestamp: a.mediaKeyTimestamp, type: a.type, signal: controller.signal
      });
      var bytes = new Uint8Array(buffer);
      if (bytes.length > maxBytes) return { unavailable: "TOO_LARGE" };
      var token = "m" + String(Math.random()).slice(2) + Date.now();
      mediaBuffers.set(token, { bytes: bytes, mimeType: a.mimetype || "application/octet-stream" });
      return { token: token, size: bytes.length, mimeType: a.mimetype || "application/octet-stream", fileName: a.filename || null };
    } catch (error) {
      return { unavailable: "DOWNLOAD_FAILED", message: error && error.message ? String(error.message).slice(0, 200) : null };
    } finally {
      clearTimeout(timer);
    }
  }

  function readMediaChunk(params) {
    var entry = mediaBuffers.get(params.token);
    if (!entry || !entry.bytes) fail("MEDIA_TOKEN_UNKNOWN");
    var offset = Math.max(0, Number(params.offset) || 0);
    var length = Math.min(Number(params.length) || CHUNK_BYTES, CHUNK_BYTES);
    var slice = entry.bytes.subarray(offset, offset + length);
    return { chunk: b64FromBytes(slice), done: offset + slice.length >= entry.bytes.length };
  }

  function releaseMedia(params) {
    mediaBuffers.delete(params.token);
    return { released: true };
  }

  async function openChat(params) {
    need("openChat");
    var chat = await getChat(params.chatKey, true);
    if (!chat) fail("CHAT_UNAVAILABLE");
    var cmd = m().Cmd;
    if (typeof cmd.openChatBottom === "function") await cmd.openChatBottom({ chat: chat });
    else await cmd.openChatAt({ chat: chat, noFocus: true });
    return { opened: true, chatKey: chatKeyOf(chat) };
  }

  // Header and call modules inspected on the logged-in 2026-10-03 Web build.
  // Use its voice control to preserve consent, microphone and audio handling.
  // Never focus/create a tab, and never retry a dial after an uncertain reply.
  function callCollection() { return load("WAWebCallCollection"); }
  function callState(call) {
    var utils = load("WAWebVoipCallStateUtils");
    var state = call && typeof call.getState === "function" ? call.getState() : null;
    if (!utils || state === null) return "UNKNOWN";
    if (utils.isCallConnected(state)) return "CONNECTED";
    if (utils.isCallRinging(state)) return "RINGING";
    if (utils.isCallTerminal(state)) return "ENDED";
    return "STARTING";
  }
  function callSnapshot(params) {
    var collection = callCollection();
    if (!officeCall || officeCall.id !== params.callId) {
      // After the page reloads, absence of any provider call proves it ended.
      // An existing unknown call can only be ended in WhatsApp itself.
      if (!officeCall && collection && !collection.activeCall && !collection.pendingOutgoingCall) return { id: params.callId, status: "ENDED" };
      fail("CALL_NOT_FOUND", "This call is no longer tracked. Check WhatsApp Web.");
    }
    if (["ENDED", "FAILED"].includes(officeCall.status)) return { id: officeCall.id, status: officeCall.status, startedAt: officeCall.startedAt };
    var active = collection && collection.activeCall;
    if (active && officeCall.dialed && !officeCall.nativeCall) {
      var peer = MAP.serializeWid(active.peerJid);
      if (active.outgoing === true && peer && officeCall.chatKeys.indexOf(peer) !== -1) officeCall.nativeCall = active;
    }
    if (officeCall.nativeCall && active === officeCall.nativeCall) {
      officeCall.status = callState(active);
    } else if (officeCall.nativeCall) {
      officeCall.status = "ENDED";
    } else if (officeCall.dialed && collection && collection.pendingOutgoingCall) {
      // Pending calls have no peer identifier on this Web build. Only the
      // object created synchronously by our click can be cancelled safely.
      if (officeCall.pending !== collection.pendingOutgoingCall) officeCall.status = "UNKNOWN";
    } else if (officeCall.dialed && Date.now() - officeCall.startedAt > 15000 && officeCall.status !== "ENDED") {
      officeCall.status = "FAILED";
    }
    return { id: officeCall.id, status: officeCall.status, startedAt: officeCall.startedAt };
  }
  async function startCall(params) {
    if (!/^[0-9a-f-]{36}$/i.test(String(params.callId || ""))) fail("INVALID_CALL");
    if (officeCall && officeCall.id === params.callId) return callSnapshot(params);
    var collection = callCollection();
    if (!collection || !load("WAWebVoipCallStateUtils")) fail("CAPABILITY_UNAVAILABLE", "Calling is unavailable in this WhatsApp Web version");
    if (collection.activeCall || collection.pendingOutgoingCall || (officeCall && !["ENDED", "FAILED"].includes(officeCall.status))) fail("CALL_BUSY", "A call is already in progress");
    var record = officeCall = { id: params.callId, status: "STARTING", startedAt: Date.now(), dialed: false, chatKeys: [] };
    var opened = await openChat(params);
    var chat = await getChat(opened.chatKey, false);
    if (!chat) fail("CHAT_UNAVAILABLE");
    record.chatKeys = [params.chatKey, chatKeyOf(chat)];
    var lids = load("WAWebLidMigrationUtils");
    if (lids) {
      try { record.chatKeys.push(MAP.serializeWid(lids.toLid(chat.id)), MAP.serializeWid(lids.toPn(chat.id))); } catch (error) { /* optional aliases */ }
    }
    record.chatKeys = record.chatKeys.filter(Boolean);
    for (var attempt = 0; attempt < 40; attempt += 1) {
      if (record.status === "ENDED") return callSnapshot(params);
      if (collection.activeCall || collection.pendingOutgoingCall) { record.status = "FAILED"; fail("CALL_BUSY"); }
      // Opening can replace a PN model with its LID model asynchronously.
      chat = findChatModel(opened.chatKey) || findChatModel(chatKeyOf(chat));
      var button = document.querySelector('#main header button[aria-label="Voice call"]');
      if (chat && chat.active && button && !button.disabled && button.getAttribute("aria-disabled") !== "true") {
        record.dialed = true;
        button.click();
        record.pending = collection.pendingOutgoingCall || null;
        return callSnapshot(params);
      }
      await new Promise(function (resolve) { setTimeout(resolve, 100); });
    }
    record.status = "FAILED";
    fail("CAPABILITY_UNAVAILABLE", "The voice-call button is unavailable for this contact. Check WhatsApp Web.");
  }
  async function endCall(params) {
    var snapshot = callSnapshot(params);
    if (!officeCall) return snapshot;
    var record = officeCall;
    var collection = callCollection();
    if (["ENDED", "FAILED"].includes(record.status)) return callSnapshot(params);
    // Cancels opening a chat before the voice control is clicked.
    if (!record.dialed) { record.status = "ENDED"; return callSnapshot(params); }
    if (record.nativeCall && collection.activeCall === record.nativeCall) {
      var stackModule = load("WAWebVoipStackInterface");
      var enums = load("WAWebVoipSignalingEnums");
      if (!stackModule || !enums || !enums.EndCallReason) fail("CAPABILITY_UNAVAILABLE", "End this call in WhatsApp Web");
      var stack = await stackModule.getVoipStackInterface();
      // Loading the stack can yield; never terminate a replacement call.
      if (collection.activeCall !== record.nativeCall) return callSnapshot(params);
      if (!stack || stack.type !== "web" || typeof stack.endCall !== "function") fail("CAPABILITY_UNAVAILABLE", "End this call in WhatsApp Web");
      record.nativeCall.userEndedCall = true;
      await stack.endCall(enums.EndCallReason.Self, true);
    } else if (record.pending && collection.pendingOutgoingCall === record.pending) {
      var cancel = load("WAWebVoipCancelOutgoingCall");
      if (!cancel || typeof cancel.cancelPendingOutgoingCall !== "function") fail("CAPABILITY_UNAVAILABLE", "End this call in WhatsApp Web");
      cancel.cancelPendingOutgoingCall();
      record.status = "ENDED";
    } else {
      fail("CALL_UNCERTAIN", "Check WhatsApp Web to end the call safely");
    }
    return callSnapshot(params);
  }

  async function markRead(params) {
    need("markRead");
    var chat = await getChat(params.chatKey, false);
    if (!chat) fail("NOT_SENT_CHAT_UNAVAILABLE");
    try { await m().Seen.sendSeen(chat, false); } catch (error) { fail("SEND_UNCERTAIN", "mark read threw"); }
    return { ok: true };
  }

  async function react(params) {
    need("react");
    var msg = m().Msg.get(params.targetProviderMessageId);
    if (!msg) fail("NOT_SENT_TARGET_UNAVAILABLE", "The message to react to is not loaded in WhatsApp Web");
    try { await m().Reaction.sendReactionToMsg(msg, String(params.emoji || "")); } catch (error) { fail("SEND_UNCERTAIN", "reaction threw"); }
    return { ok: true };
  }

  var METHODS = {
    getIdentity: function () { return identity(); },
    getCapabilities: function () { return capabilities(); },
    selfTest: selfTest,
    listDirectChats: listDirectChats,
    fetchMessages: fetchMessages,
    resolveContact: resolveContact,
    prepareSend: prepareSend,
    commitSend: commitSend,
    messageExists: messageExists,
    stageMedia: stageMedia,
    sendMedia: sendMedia,
    fetchMedia: fetchMedia,
    readMediaChunk: readMediaChunk,
    releaseMedia: releaseMedia,
    openChat: openChat,
    startCall: startCall,
    callStatus: callSnapshot,
    endCall: endCall,
    markRead: markRead,
    react: react,
    setRole: function (params) { capture = params && params.capture !== false; return { capture: capture }; },
    publishActiveChat: function () { publishActiveChat(); return { ok: true }; }
  };

  window.addEventListener("message", function (event) {
    if (event.source !== window || event.origin !== window.location.origin) return;
    var data = event.data;
    if (!data || data.source !== "ugow-bridge" || data.nonce !== nonce() || data.kind !== "rpc") return;
    var handler = Object.prototype.hasOwnProperty.call(METHODS, data.method) ? METHODS[data.method] : null;
    Promise.resolve()
      .then(function () {
        if (!handler) fail("UNKNOWN_METHOD");
        return handler(data.params || {});
      })
      .then(function (result) { post("rpc-result", { id: data.id, ok: true, result: result }); })
      .catch(function (error) {
        if (data.method === "startCall" && officeCall && data.params && officeCall.id === data.params.callId && !officeCall.dialed) officeCall.status = "FAILED";
        post("rpc-result", { id: data.id, ok: false, error: { code: error && error.code || "ADAPTER_ERROR", message: error && error.message ? String(error.message).slice(0, 300) : "error" } });
      });
  });

  // Wait for the WhatsApp client to finish loading, then keep reporting identity.
  var delay = 1000;
  function tick() {
    try { publishIdentity(false); } catch (error) { /* keep polling */ }
    delay = subscribed ? 5000 : Math.min(delay + 500, 5000);
    setTimeout(tick, delay);
  }
  setTimeout(tick, 500);
  setInterval(function () { try { publishIdentity(true); } catch (error) { /* ignore */ } }, 30000);
})();
