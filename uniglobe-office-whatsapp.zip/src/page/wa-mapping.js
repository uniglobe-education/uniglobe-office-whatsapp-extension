// Pure mapping from WhatsApp Web message models to protocol events.
// Classic script (MAIN world, no imports). Exposes globalThis.UGOW_MAPPING.
// Tests load this file with node:vm and feed it fake message objects.
//
// Nothing here trusts its input: WhatsApp's internal models change shape
// between releases, so every field is read defensively and anything
// unrecognised becomes an honest "unsupported" placeholder rather than a crash.
(function (root) {
  "use strict";

  // Must stay identical to packages/office-whatsapp-protocol (tested).
  var DIRECT_CHAT_RE = /^[0-9A-Za-z._:-]{3,120}@(c\.us|s\.whatsapp\.net|lid)$/;
  var EXCLUDED_CHAT_RE = /(@g\.us|@broadcast|@newsletter|^status@|@call)$/;
  var OPAQUE_RE = /^[\x21-\x7e]{1,300}$/;

  // WhatsApp internal message types that are system traffic, never student
  // messages. "ciphertext" is a not-yet-decrypted message: it is emitted later
  // when its type changes, so it is skipped here rather than stored as blank.
  var SYSTEM_TYPES = {
    e2e_notification: 1, notification: 1, notification_template: 1, gp2: 1,
    call_log: 1, protocol: 1, ciphertext: 1, broadcast_notification: 1,
    newsletter_notification: 1, pinned_message: 1, keep_in_chat: 1
  };
  var KIND_BY_TYPE = {
    chat: "text", image: "image", video: "video", gif: "video", audio: "audio", ptt: "voice",
    document: "document", sticker: "sticker", location: "location", vcard: "contact",
    multi_vcard: "contact", revoked: "deleted"
  };
  var MEDIA_KINDS = { image: 1, video: 1, audio: 1, voice: 1, document: 1, sticker: 1 };
  var ACK_BY_CODE = { "-1": "FAILED", "0": "PENDING", "1": "SENT", "2": "DELIVERED", "3": "READ", "4": "PLAYED" };

  function isDirectChatKey(chatKey) {
    return typeof chatKey === "string" && DIRECT_CHAT_RE.test(chatKey) && !EXCLUDED_CHAT_RE.test(chatKey);
  }

  function phoneFromChatKey(chatKey) {
    var match = /^(\d{7,15})@(c\.us|s\.whatsapp\.net)$/.exec(String(chatKey || ""));
    return match ? "+" + match[1] : null;
  }

  function serializeWid(wid) {
    if (!wid) return null;
    if (typeof wid === "string") return wid;
    if (typeof wid._serialized === "string") return wid._serialized;
    if (wid.user && wid.server) return wid.user + "@" + wid.server;
    return null;
  }

  function serializeKey(key) {
    if (!key) return null;
    if (typeof key === "string") return key;
    if (typeof key._serialized === "string") return key._serialized;
    var remote = serializeWid(key.remote);
    if (remote && key.id) return (key.fromMe ? "true" : "false") + "_" + remote + "_" + key.id;
    return null;
  }

  function text(value, max) {
    if (typeof value !== "string" || !value) return null;
    return value.length > max ? value.slice(0, max) : value;
  }

  function toInt(value) {
    var n = Number(value);
    return Number.isFinite(n) && n >= 0 ? Math.round(n) : null;
  }

  function isoFromSeconds(t) {
    var n = Number(t);
    if (!Number.isFinite(n) || n <= 0) return null;
    return new Date(n * 1000).toISOString();
  }

  function hexEmoji(emoji) {
    if (!emoji) return "none";
    var parts = [];
    for (var ch of String(emoji)) parts.push(ch.codePointAt(0).toString(16));
    return parts.join("-").slice(0, 60);
  }

  function parseVcardPhones(vcard) {
    var phones = [];
    String(vcard || "").split(/\r?\n/).forEach(function (line) {
      if (/^(item\d+\.)?TEL/i.test(line)) {
        var value = line.slice(line.indexOf(":") + 1).trim();
        if (value) phones.push(value.slice(0, 40));
      }
    });
    return phones.slice(0, 10);
  }

  // Reads a raw WhatsApp message model into a plain snapshot. Accepts either a
  // Backbone-like model (with .get / .attributes) or a plain object.
  function readMsg(raw, extra) {
    if (!raw) return null;
    var a = raw.attributes && typeof raw.attributes === "object" ? Object.assign({}, raw.attributes, raw) : raw;
    var key = a.id || {};
    var id = serializeKey(key);
    var remote = serializeWid(key.remote) || serializeWid(a.to && key.fromMe ? a.to : a.from);
    var type = typeof a.type === "string" ? a.type : "unknown";
    var fromMe = key.fromMe === true;
    return {
      id: id,
      fromMe: fromMe,
      chatKey: remote,
      type: type,
      body: typeof a.body === "string" ? a.body : null,
      caption: typeof a.caption === "string" ? a.caption : null,
      fileName: typeof a.filename === "string" ? a.filename : null,
      mimeType: typeof a.mimetype === "string" ? a.mimetype : null,
      size: toInt(a.size),
      duration: toInt(a.duration),
      t: Number(a.t) || null,
      ack: typeof a.ack === "number" ? a.ack : null,
      quotedId: (extra && extra.quotedId) || null,
      isForwarded: a.isForwarded === true,
      isViewOnce: a.isViewOnce === true,
      ephemeral: Number(a.ephemeralDuration) > 0,
      isStatus: a.isStatusV3 === true || remote === "status@broadcast",
      broadcast: a.broadcast === true,
      lat: a.lat, lng: a.lng, loc: typeof a.loc === "string" ? a.loc : null,
      vcardName: typeof a.vcardFormattedName === "string" ? a.vcardFormattedName : null,
      reactionTargetId: serializeKey(a.reactionParentKey || a.parentMsgKey),
      reactionTimestampMs: Number(a.reactionTimestamp) || (Number(a.t) ? Number(a.t) * 1000 : null),
      editTimestampMs: Number(a.latestEditSenderTimestampMs) || null,
      // Media that the Web client cannot hand over (e.g. no download path).
      hasMediaPath: Boolean(a.directPath || a.deprecatedMms3Url || a.clientUrl)
    };
  }

  function basePeer(snap, context) {
    var phone = phoneFromChatKey(snap.chatKey) || (context && context.phoneE164) || null;
    return {
      providerId: snap.chatKey,
      phoneE164: phone,
      displayName: (context && context.displayName) ? text(context.displayName, 200) : null
    };
  }

  function usable(snap) {
    return snap && snap.id && OPAQUE_RE.test(snap.id) && isDirectChatKey(snap.chatKey) && !snap.isStatus && !snap.broadcast;
  }

  function buildMessage(snap) {
    var kind = KIND_BY_TYPE[snap.type] || "unsupported";
    var message = {
      kind: kind,
      text: null,
      caption: null,
      quotedProviderMessageId: snap.quotedId && OPAQUE_RE.test(snap.quotedId) ? snap.quotedId : null,
      forwarded: snap.isForwarded,
      viewOnce: snap.isViewOnce,
      ephemeral: snap.ephemeral,
      providerType: text(snap.type, 60)
    };
    if (kind === "text") message.text = text(snap.body, 65536) || "";
    if (MEDIA_KINDS[kind]) {
      message.caption = text(snap.caption, 4096);
      var downloadable = !snap.isViewOnce && snap.hasMediaPath;
      message.media = {
        fileName: text(snap.fileName, 255),
        mimeType: snap.mimeType && /^[\w.+-]+\/[\w.+-]+(?:;.*)?$/.test(snap.mimeType) ? text(snap.mimeType, 120) : null,
        size: snap.size,
        durationSeconds: snap.duration !== null && snap.duration <= 86400 ? snap.duration : null,
        downloadable: downloadable,
        unavailableReason: snap.isViewOnce ? "VIEW_ONCE" : (downloadable ? null : "NO_MEDIA_PATH")
      };
    }
    if (kind === "location") {
      var lat = Number(snap.lat);
      var lng = Number(snap.lng);
      if (Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
        message.location = { latitude: lat, longitude: lng, name: text(snap.loc, 300) };
      }
    }
    if (kind === "contact") {
      message.contact = { name: text(snap.vcardName, 200), phones: parseVcardPhones(snap.body) };
    }
    if (kind === "unsupported") message.text = "[" + (text(snap.type, 40) || "unknown") + " message — open WhatsApp to view]";
    return message;
  }

  // Returns the events for one message snapshot (possibly none).
  // context: { mode, observedAt, phoneE164, displayName }
  function buildMessageEvents(snap, context) {
    if (!usable(snap)) return [];
    if (SYSTEM_TYPES[snap.type]) return [];
    var occurredAt = isoFromSeconds(snap.t);
    if (!occurredAt) return [];
    var observedAt = (context && context.observedAt) || new Date().toISOString();
    var mode = (context && context.mode) || "LIVE";
    if (snap.type === "reaction") {
      var reaction = buildReactionEvent(snap, context);
      return reaction ? [reaction] : [];
    }
    var ackName = snap.ack === null ? null : ACK_BY_CODE[String(snap.ack)] || null;
    var upsert = {
      eventKey: "msg:" + snap.id,
      type: "MESSAGE_UPSERT",
      chatKey: snap.chatKey,
      providerMessageId: snap.id,
      direction: snap.fromMe ? "OUTBOUND" : "INBOUND",
      peer: basePeer(snap, context),
      occurredAt: occurredAt,
      observedAt: observedAt,
      mode: mode,
      message: buildMessage(snap),
      // The service worker upgrades this to CRM_COMMAND (with clientCommandId)
      // when the id is in its command journal. The Web client cannot tell a
      // phone send from another linked device, so we do not guess.
      senderAttribution: snap.fromMe ? "LINKED_DEVICE_UNKNOWN" : "STUDENT",
      ack: snap.fromMe && ackName && ackName !== "FAILED" ? ackName : null
    };
    var events = [upsert];
    if (snap.fromMe && ackName === "FAILED") events.push(buildAckEvent(snap, context));
    return events;
  }

  function buildAckEvent(snap, context) {
    if (!usable(snap) || !snap.fromMe) return null;
    var ack = ACK_BY_CODE[String(snap.ack)];
    if (!ack) return null;
    var observedAt = (context && context.observedAt) || new Date().toISOString();
    return {
      eventKey: "ack:" + snap.id + ":" + ack,
      type: "MESSAGE_ACK",
      chatKey: snap.chatKey,
      providerMessageId: snap.id,
      peer: basePeer(snap, context),
      occurredAt: observedAt,
      observedAt: observedAt,
      mode: (context && context.mode) || "LIVE",
      ack: ack
    };
  }

  function buildRevokeEvent(snap, context) {
    if (!usable(snap)) return null;
    var observedAt = (context && context.observedAt) || new Date().toISOString();
    return {
      eventKey: "revoke:" + snap.id,
      type: "MESSAGE_REVOKE",
      chatKey: snap.chatKey,
      providerMessageId: snap.id,
      peer: basePeer(snap, context),
      occurredAt: observedAt,
      observedAt: observedAt,
      mode: (context && context.mode) || "LIVE",
      revokedBy: "SENDER"
    };
  }

  // Edit revision = seconds between the original send and the edit. WhatsApp
  // only allows edits for ~15 minutes, so this stays small, is monotonic, and
  // is the same no matter which tab or restart observes it.
  function buildEditEvent(snap, context) {
    if (!usable(snap) || !snap.editTimestampMs || !snap.t) return null;
    var revision = Math.max(1, Math.min(100000, Math.round(snap.editTimestampMs / 1000 - snap.t)));
    var observedAt = (context && context.observedAt) || new Date().toISOString();
    return {
      eventKey: "edit:" + snap.id + ":" + revision,
      type: "MESSAGE_EDIT",
      chatKey: snap.chatKey,
      providerMessageId: snap.id,
      peer: basePeer(snap, context),
      occurredAt: new Date(snap.editTimestampMs).toISOString(),
      observedAt: observedAt,
      mode: (context && context.mode) || "LIVE",
      revision: revision,
      text: text(snap.body, 65536) || ""
    };
  }

  function buildReactionEvent(snap, context) {
    if (!usable(snap) || !snap.reactionTargetId || !OPAQUE_RE.test(snap.reactionTargetId)) return null;
    var ms = snap.reactionTimestampMs || Date.now();
    var emoji = typeof snap.body === "string" ? snap.body.slice(0, 16) : "";
    var observedAt = (context && context.observedAt) || new Date().toISOString();
    return {
      eventKey: "react:" + snap.reactionTargetId + ":" + (snap.fromMe ? "me" : "peer") + ":" + hexEmoji(emoji) + ":" + ms,
      type: "REACTION",
      chatKey: snap.chatKey,
      providerMessageId: snap.id,
      peer: basePeer(snap, context),
      occurredAt: new Date(ms).toISOString(),
      observedAt: observedAt,
      mode: (context && context.mode) || "LIVE",
      targetProviderMessageId: snap.reactionTargetId,
      emoji: emoji,
      fromMe: snap.fromMe
    };
  }

  // Only emitted when the Web client itself exposes an opaque-id → phone link.
  function buildMappingEvent(chatKey, phoneE164, displayName) {
    if (!isDirectChatKey(chatKey) || !/^\+[1-9]\d{6,14}$/.test(String(phoneE164 || ""))) return null;
    var now = new Date().toISOString();
    return {
      eventKey: "map:" + chatKey + ":" + phoneE164,
      type: "CONTACT_MAPPING",
      chatKey: chatKey,
      peer: { providerId: chatKey, phoneE164: phoneE164, displayName: displayName ? text(displayName, 200) : null },
      occurredAt: now,
      observedAt: now,
      mode: "LIVE"
    };
  }

  root.UGOW_MAPPING = {
    isDirectChatKey: isDirectChatKey,
    phoneFromChatKey: phoneFromChatKey,
    serializeWid: serializeWid,
    serializeKey: serializeKey,
    readMsg: readMsg,
    buildMessageEvents: buildMessageEvents,
    buildAckEvent: buildAckEvent,
    buildRevokeEvent: buildRevokeEvent,
    buildEditEvent: buildEditEvent,
    buildReactionEvent: buildReactionEvent,
    buildMappingEvent: buildMappingEvent,
    hexEmoji: hexEmoji,
    ACK_BY_CODE: ACK_BY_CODE
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
