// UniGlobe sidebar inside WhatsApp Web. Classic content script (isolated
// world), rendered in a closed shadow root so neither side's CSS leaks.
//
// Layout: the sidebar is docked to the right edge and WhatsApp's #app is
// narrowed by the same width (CSS variable --ugow-width), so WhatsApp re-flows
// its own panes instead of being covered. Collapsed, only a 28px rail is
// reserved; open, at most 320px (and never more than 35% of the window). The
// native chat list, composer and media controls are never overlapped.
//
// All data comes from the service worker; CRM tokens never reach this script.
// Everything is rendered with textContent (no HTML from the server).
(function () {
  "use strict";
  if (window.__ugowSidebarLoaded) return;
  window.__ugowSidebarLoaded = true;

  var bus = window.__ugowBus;
  if (!bus) return;

  var RAIL = 28;
  var OPEN = 320;
  var state = { open: false, facts: null, chat: null, requestId: 0, context: null, loading: false, error: null, busy: false, message: null };

  function widthPx() {
    return state.open ? Math.min(OPEN, Math.round(window.innerWidth * 0.35)) : RAIL;
  }

  function applyLayout() {
    document.documentElement.style.setProperty("--ugow-width", widthPx() + "px");
    if (host) host.style.width = widthPx() + "px";
  }

  var host = null;
  var root = null;

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (key) {
      if (key === "text") node.textContent = attrs[key];
      else if (key === "class") node.className = attrs[key];
      else if (key.slice(0, 2) === "on") node.addEventListener(key.slice(2), attrs[key]);
      else if (attrs[key] !== null && attrs[key] !== undefined && attrs[key] !== false) node.setAttribute(key, attrs[key] === true ? "" : attrs[key]);
    });
    (children || []).forEach(function (child) { if (child) node.appendChild(typeof child === "string" ? document.createTextNode(child) : child); });
    return node;
  }

  var CSS = [
    ":host{all:initial}",
    ".wrap{position:fixed;top:0;right:0;bottom:0;display:flex;font:13px/1.45 system-ui,-apple-system,'Segoe UI',sans-serif;color:#0f172a;z-index:2147483000}",
    ".rail{width:28px;background:#0f766e;display:flex;flex-direction:column;align-items:center;padding-top:88px}",
    ".rail button{all:unset;cursor:pointer;color:#fff;writing-mode:vertical-rl;transform:rotate(180deg);padding:10px 4px;border-radius:6px;font-weight:600;font-size:12px}",
    ".rail button:focus-visible{outline:2px solid #fff}",
    ".panel{flex:1;min-width:0;background:#fff;border-left:1px solid #e2e8f0;overflow-y:auto;padding:12px 14px}",
    "h2{font-size:14px;margin:0 0 2px}",
    ".muted{color:#64748b;font-size:12px}",
    ".card{border:1px solid #e2e8f0;border-radius:10px;padding:10px;margin:10px 0}",
    ".badge{display:inline-block;background:#ccfbf1;color:#115e59;border-radius:999px;padding:1px 8px;font-size:11px;font-weight:600}",
    ".warn{background:#fef3c7;border-color:#fcd34d}",
    ".err{background:#fee2e2;border-color:#fca5a5}",
    "button.primary,a.primary{all:unset;cursor:pointer;background:#0f766e;color:#fff;border-radius:8px;padding:6px 10px;font-weight:600;font-size:12px;display:inline-block}",
    "button.primary:focus-visible,a.primary:focus-visible,button.link:focus-visible{outline:2px solid #0f766e;outline-offset:2px}",
    "button.primary[disabled]{opacity:.5;cursor:default}",
    "button.link{all:unset;cursor:pointer;color:#0f766e;font-size:12px;text-decoration:underline}",
    "textarea,select,input{box-sizing:border-box;width:100%;font:inherit;border:1px solid #cbd5e1;border-radius:8px;padding:6px;margin:4px 0}",
    "ul{margin:4px 0;padding-left:16px}",
    "li{margin:2px 0}",
    ".row{display:flex;gap:6px;align-items:center;justify-content:space-between}",
    ".skeleton{height:12px;background:#f1f5f9;border-radius:6px;margin:8px 0}"
  ].join("");

  function mount() {
    if (host || !document.body) return;
    var style = document.createElement("style");
    style.textContent = "#app{width:calc(100% - var(--ugow-width, 28px)) !important;}";
    (document.head || document.documentElement).appendChild(style);
    host = document.createElement("div");
    host.setAttribute("data-ugow-sidebar", "");
    host.style.cssText = "position:fixed;top:0;right:0;bottom:0;z-index:2147483000;";
    root = host.attachShadow({ mode: "closed" });
    document.body.appendChild(host);
    applyLayout();
    render();
  }

  function sessionGuidance(facts) {
    var session = facts && facts.session || {};
    var wa = facts && facts.whatsapp || {};
    var expected = facts && facts.expectedPhoneE164;
    if (!facts || !facts.paired || session.state === "NONE") {
      return { tone: "warn", title: "Not connected to UniGlobe CRM", body: "Open the UniGlobe CRM in this browser profile and sign in. It connects this WhatsApp automatically." };
    }
    if (session.state === "REVOKED" || session.state === "EXPIRED") {
      return { tone: "warn", title: "Connection ended", body: "Your CRM session ended. Sign in to the UniGlobe CRM again to reconnect." };
    }
    if (wa.state === "LOGGED_OUT") {
      return { tone: "warn", title: "Link your office WhatsApp", body: "On the phone for " + (expected || "your office number") + ", open WhatsApp → Settings → Linked devices → Link a device, and scan the code on this page." };
    }
    if (session.state === "MISMATCH") {
      return { tone: "err", title: "Wrong WhatsApp number", body: "This WhatsApp is " + (wa.observedPhoneE164 || "an unknown number") + " but your CRM office number is " + (expected || "different") + ". Syncing and sending are paused. Log out here (Menu → Log out) and link the correct number." };
    }
    if (wa.state === "ADAPTER_ERROR") {
      return { tone: "err", title: "WhatsApp Web changed", body: "UniGlobe could not read this WhatsApp Web version. Messages are not syncing. Ask your admin to update the extension." };
    }
    if (session.state !== "ACTIVE") {
      return { tone: "warn", title: "Connecting…", body: "Checking your WhatsApp number with the CRM." };
    }
    return null;
  }

  function render() {
    if (!root) return;
    root.textContent = "";
    root.appendChild(el("style", { text: CSS }));
    var wrap = el("div", { class: "wrap" });
    var toggle = el("button", {
      type: "button",
      "aria-expanded": state.open ? "true" : "false",
      "aria-label": state.open ? "Hide UniGlobe panel" : "Show UniGlobe panel",
      text: state.open ? "UniGlobe ▸" : "◂ UniGlobe",
      onclick: function () { state.open = !state.open; applyLayout(); render(); if (state.open) refresh(); }
    });
    wrap.appendChild(el("div", { class: "rail" }, [toggle]));
    if (state.open) wrap.appendChild(el("div", { class: "panel", role: "complementary", "aria-label": "UniGlobe student panel" }, panelContent()));
    root.appendChild(wrap);
  }

  function panelContent() {
    var out = [el("div", { class: "row" }, [el("h2", { text: "UniGlobe" }), state.facts && state.facts.session && state.facts.session.state === "ACTIVE" ? el("span", { class: "badge", text: "Connected" }) : null])];
    var guidance = sessionGuidance(state.facts);
    if (guidance) {
      out.push(el("div", { class: "card " + guidance.tone, role: "status" }, [el("strong", { text: guidance.title }), el("p", { text: guidance.body })]));
      return out;
    }
    if (!state.chat || !state.chat.chatKey) {
      out.push(el("p", { class: "muted", text: "Open a chat to see the student." }));
      return out;
    }
    if (!state.chat.direct) {
      out.push(el("p", { class: "muted", text: "Group chats, status and channels are not synced to the CRM." }));
      return out;
    }
    if (state.loading) {
      out.push(el("div", { class: "skeleton" }), el("div", { class: "skeleton" }), el("div", { class: "skeleton" }));
      return out;
    }
    if (state.error) {
      out.push(el("div", { class: "card err", role: "alert" }, [el("p", { text: state.error }), el("button", { class: "link", type: "button", text: "Try again", onclick: refresh })]));
      return out;
    }
    var ctx = state.context;
    if (!ctx) return out;
    if (state.message) out.push(el("div", { class: "card", role: "status" }, [el("p", { text: state.message })]));
    if (ctx.match === "NONE") {
      out.push(el("p", { class: "muted", text: "No student yet. When this contact messages your office number, the CRM creates the student automatically." }));
    } else if (ctx.match === "RESTRICTED") {
      out.push(el("div", { class: "card warn" }, [el("strong", { text: "Another counselor's student" }), el("p", { text: (ctx.lead && ctx.lead.ownerName ? ctx.lead.ownerName + " owns this student." : "This student belongs to another counselor.") + " Messages on your number are still recorded. Ask a manager if ownership should change." })]));
    } else if (ctx.match === "REVIEW") {
      out.push(el("div", { class: "card warn" }, [el("strong", { text: "Waiting for review" }), el("p", { text: "A manager is reviewing this contact before a student record is created or linked." })]));
    } else if (ctx.match === "EXCLUDED") {
      out.push(el("p", { class: "muted", text: "This contact is excluded from student tracking (staff, business or personal)." }));
    } else if (ctx.match === "LEAD" && ctx.lead) {
      out.push.apply(out, leadSection(ctx));
    }
    if (ctx.canClassify) out.push(classifySection(ctx));
    return out;
  }

  // "Not a student": teammates, partners and others are hidden from the CRM.
  var CATEGORY_TEXT = { TEAMMATE: "a teammate", PARTNER: "a partner", JOB_SEEKER: "a job seeker", OTHER: "not a student" };
  function classifySection(ctx) {
    var common = ctx.commonContact;
    var hint = common && common.markedBy && common.markedBy[0];
    var hintCategory = hint && CATEGORY_TEXT[hint.category] ? hint.category : "OTHER";
    var done = "Done — this chat is hidden from the CRM and not counted as a student.";
    var children = [el("strong", { text: "Not a student?" })];
    if (hint) children.push(el("p", { text: hint.name + " marked this number as " + CATEGORY_TEXT[hintCategory] + ". Is it " + CATEGORY_TEXT[hintCategory] + " for you too?" }));
    else if (common) children.push(el("p", { text: "This number also chats with " + common.otherStaffCount + " other staff office number" + (common.otherStaffCount === 1 ? "" : "s") + ". It may be a teammate or partner." }));
    else children.push(el("p", { class: "muted", text: "Teammates, partners and other non-students are hidden from the CRM. You keep chatting here." }));
    if (hint) {
      children.push(el("button", { class: "primary", type: "button", disabled: state.busy, text: "Yes, " + CATEGORY_TEXT[hintCategory], onclick: function () { act({ action: "CLASSIFY", category: hintCategory }, done); } }));
    } else {
      var pick = el("select", { "aria-label": "Not a student category" }, [
        el("option", { value: "TEAMMATE", text: "Teammate" }),
        el("option", { value: "PARTNER", text: "Partner" }),
        el("option", { value: "OTHER", text: "Other" })
      ]);
      children.push(pick, el("button", { class: "primary", type: "button", disabled: state.busy, text: "Mark as not a student", onclick: function () { act({ action: "CLASSIFY", category: pick.value }, done); } }));
    }
    if (common) children.push(el("button", { class: "link", type: "button", text: "It's a student", onclick: function () { act({ action: "CLASSIFY", category: "STUDENT" }, "Kept as a student."); } }));
    return el("div", { class: "card" }, children);
  }

  function fmtDate(value) {
    var d = new Date(value);
    return Number.isNaN(d.getTime()) ? "" : d.toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
  }

  function leadSection(ctx) {
    var lead = ctx.lead;
    var allowed = Array.isArray(ctx.allowedActions) ? ctx.allowedActions : [];
    var details = [
      el("h2", { text: lead.name || "Student" }),
      el("p", { class: "muted", text: [lead.leadCode, lead.status, lead.ownerName ? "Owner: " + lead.ownerName : null].filter(Boolean).join(" · ") }),
      el("p", { class: "muted", text: [lead.countryInterest ? "Destination: " + lead.countryInterest : null, lead.city ? "City: " + lead.city : null].filter(Boolean).join(" · ") })
    ];
    if (ctx.crmUrl) details.push(el("a", { class: "primary", href: ctx.crmUrl, target: "_blank", rel: "noopener noreferrer", text: "Open in CRM" }));
    var out = [el("div", { class: "card" }, details)];

    var followUps = Array.isArray(ctx.followUps) ? ctx.followUps : [];
    out.push(el("div", { class: "card" }, [
      el("strong", { text: "Follow-ups" }),
      followUps.length ? el("ul", {}, followUps.slice(0, 5).map(function (f) {
        return el("li", {}, [
          (f.note || f.title || "Follow-up") + " — " + fmtDate(f.dueAt) + " ",
          allowed.indexOf("COMPLETE_FOLLOW_UP") >= 0 && f.status !== "COMPLETED" ? el("button", { class: "link", type: "button", text: "Done", onclick: function () { act({ action: "COMPLETE_FOLLOW_UP", followUpId: f.id }, "Follow-up completed"); } }) : null
        ]);
      })) : el("p", { class: "muted", text: "No open follow-ups." })
    ]));

    var notes = Array.isArray(ctx.notes) ? ctx.notes : [];
    out.push(el("div", { class: "card" }, [
      el("strong", { text: "Recent notes" }),
      notes.length ? el("ul", {}, notes.slice(0, 5).map(function (n) {
        return el("li", { text: (n.body || "") + (n.authorName ? " — " + n.authorName : "") });
      })) : el("p", { class: "muted", text: "No notes yet." })
    ]));

    if (allowed.indexOf("NOTE") >= 0) {
      var note = el("textarea", { rows: "3", "aria-label": "Add a note", placeholder: "Add a note for the student record" });
      out.push(el("div", { class: "card" }, [el("strong", { text: "Add note" }), note, el("button", { class: "primary", type: "button", disabled: state.busy, text: "Save note", onclick: function () {
        var body = note.value.trim();
        if (body) act({ action: "NOTE", body: body }, "Note saved");
      } })]));
    }
    if (allowed.indexOf("STATUS") >= 0 && Array.isArray(ctx.statusOptions) && ctx.statusOptions.length) {
      var select = el("select", { "aria-label": "Student status" }, ctx.statusOptions.map(function (o) {
        return el("option", { value: o.value, selected: o.value === lead.status, text: o.label || o.value });
      }));
      out.push(el("div", { class: "card" }, [el("strong", { text: "Status" }), select, el("button", { class: "primary", type: "button", disabled: state.busy, text: "Update status", onclick: function () {
        if (select.value && select.value !== lead.status) act({ action: "STATUS", status: select.value }, "Status updated");
      } })]));
    }
    if (allowed.indexOf("FOLLOW_UP") >= 0) {
      var due = el("input", { type: "datetime-local", "aria-label": "Follow-up due" });
      var fnote = el("input", { type: "text", "aria-label": "Follow-up note", placeholder: "What to follow up" });
      out.push(el("div", { class: "card" }, [el("strong", { text: "Schedule follow-up" }), due, fnote, el("button", { class: "primary", type: "button", disabled: state.busy, text: "Schedule", onclick: function () {
        if (!due.value) return;
        act({ action: "FOLLOW_UP", dueAt: new Date(due.value).toISOString(), note: fnote.value.trim() || null }, "Follow-up scheduled");
      } })]));
    }
    return out;
  }

  function act(action, doneMessage) {
    var chatKey = state.chat && state.chat.chatKey;
    if (!chatKey || state.busy) return;
    state.busy = true;
    state.message = null;
    render();
    bus.send({ type: "SIDEBAR_ACTION", chatKey: chatKey, action: action }).then(function (reply) {
      state.busy = false;
      if (!state.chat || state.chat.chatKey !== chatKey) return;
      state.message = reply && reply.ok ? doneMessage : (reply && reply.error) || "That did not save. Try again.";
      if (reply && reply.ok) refresh(); else render();
    }).catch(function () { state.busy = false; state.message = "That did not save. Try again."; render(); });
  }

  // Each lookup gets an id; a reply for an older chat is discarded, and the
  // previous student is cleared immediately so it is never shown for the next chat.
  function refresh() {
    if (!state.open) { render(); return; }
    var chat = state.chat;
    state.context = null;
    state.error = null;
    if (!chat || !chat.direct || sessionGuidance(state.facts)) { state.loading = false; render(); return; }
    state.requestId += 1;
    var id = state.requestId;
    state.loading = true;
    render();
    bus.send({ type: "SIDEBAR_CONTEXT", chatKey: chat.chatKey }).then(function (reply) {
      if (id !== state.requestId) return;
      state.loading = false;
      if (reply && reply.ok) state.context = reply.context;
      else state.error = (reply && reply.error) || "Could not load the student.";
      render();
    }).catch(function () {
      if (id !== state.requestId) return;
      state.loading = false;
      state.error = "Could not reach the UniGlobe extension.";
      render();
    });
  }

  bus.on("active-chat", function (chat) {
    var changed = !state.chat || !chat || state.chat.chatKey !== chat.chatKey;
    state.chat = chat;
    if (changed) { state.message = null; refresh(); }
  });
  bus.on("facts", function (facts) {
    var before = JSON.stringify(sessionGuidance(state.facts));
    state.facts = facts;
    if (JSON.stringify(sessionGuidance(facts)) !== before) refresh(); else render();
  });
  window.addEventListener("resize", applyLayout);

  if (document.body) mount();
  else document.addEventListener("DOMContentLoaded", mount, { once: true });
  bus.send({ type: "GET_FACTS" }).then(function (reply) { if (reply && reply.facts) bus.emit("facts", reply.facts); }).catch(function () {});
})();
