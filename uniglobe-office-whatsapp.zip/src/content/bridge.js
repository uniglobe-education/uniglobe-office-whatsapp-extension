// Isolated-world bridge between the MAIN-world adapter and the service worker.
// Classic content script (no imports). Runs at document_start on
// https://web.whatsapp.com/*.
//
// The channel nonce below is handed to the MAIN world through a DOM attribute.
// It only prevents accidental cross-talk with other scripts' postMessage
// traffic. It is NOT a security boundary: any script in the page can read the
// attribute. Page payloads are therefore treated as untrusted — the service
// worker validates every event against the protocol schema, and the server
// enforces account scope. No tokens or CRM data are ever posted to the page.
(function () {
  "use strict";
  if (window.__ugowBridgeLoaded) return;
  window.__ugowBridgeLoaded = true;

  var nonce = crypto.randomUUID();
  document.documentElement.setAttribute("data-ugow-channel", nonce);

  // Tiny event bus shared with sidebar.js (same isolated world).
  var listeners = {};
  var bus = {
    on: function (name, fn) { (listeners[name] = listeners[name] || []).push(fn); },
    emit: function (name, value) { (listeners[name] || []).forEach(function (fn) { try { fn(value); } catch (error) { /* isolate listeners */ } }); },
    send: function (message) { return chrome.runtime.sendMessage(message); },
    last: {}
  };
  window.__ugowBus = bus;

  var PAGE_KINDS = { identity: 1, events: 1, "active-chat": 1, "rpc-result": 1 };
  var pending = new Map();
  var rpcSeq = 0;

  function toWorker(message) {
    try {
      var p = chrome.runtime.sendMessage(message);
      if (p && typeof p.catch === "function") p.catch(function () { /* worker restarting; it resyncs on its own */ });
    } catch (error) {
      // Extension was reloaded/updated: this content script is orphaned.
    }
  }

  // Messages are never dropped while Chrome is waking the extension's worker:
  // they wait here (bounded) and are retried until the worker takes them.
  var retryEvents = [];
  var retryTimer = null;
  var retryDelay = 1000;
  var RETRY_CAP = 5000;
  function sendEvents(events) {
    var p;
    try { p = chrome.runtime.sendMessage({ type: "PAGE_EVENTS", events: events }); } catch (error) { return; }
    if (!p || typeof p.then !== "function") return;
    var keep = function () {
      retryEvents = retryEvents.concat(events).slice(-RETRY_CAP);
      scheduleRetry();
    };
    p.then(function (reply) { if (reply && reply.retry) keep(); else retryDelay = 1000; }, keep);
  }
  function scheduleRetry() {
    if (retryTimer) return;
    retryTimer = setTimeout(function () {
      retryTimer = null;
      var batch = retryEvents.splice(0, 200);
      if (batch.length) sendEvents(batch);
      if (retryEvents.length) scheduleRetry();
      retryDelay = Math.min(retryDelay * 2, 30000);
    }, retryDelay);
  }

  window.addEventListener("message", function (event) {
    if (event.source !== window || event.origin !== window.location.origin) return;
    var data = event.data;
    if (!data || typeof data !== "object" || data.source !== "ugow-page" || data.nonce !== nonce || !PAGE_KINDS[data.kind]) return;
    if (data.kind === "rpc-result") {
      var entry = pending.get(data.id);
      if (!entry) return;
      pending.delete(data.id);
      clearTimeout(entry.timer);
      entry.resolve({ ok: data.ok === true, result: data.result, error: data.error && typeof data.error === "object" ? { code: String(data.error.code || "ADAPTER_ERROR").slice(0, 80), message: String(data.error.message || "").slice(0, 300) } : null });
      return;
    }
    if (data.kind === "events") {
      if (!Array.isArray(data.events)) return;
      sendEvents(data.events.slice(0, 200));
      return;
    }
    if (data.kind === "identity") {
      if (!data.identity || typeof data.identity !== "object") return;
      toWorker({ type: "PAGE_IDENTITY", identity: data.identity });
      return;
    }
    if (data.kind === "active-chat") {
      var chatKey = typeof data.chatKey === "string" ? data.chatKey.slice(0, 200) : null;
      bus.last.activeChat = { chatKey: chatKey, direct: data.direct === true };
      bus.emit("active-chat", bus.last.activeChat);
    }
  });

  function callPage(method, params, timeoutMs) {
    return new Promise(function (resolve) {
      rpcSeq += 1;
      var id = nonce.slice(0, 8) + "-" + rpcSeq;
      var timer = setTimeout(function () {
        pending.delete(id);
        resolve({ ok: false, error: { code: "PAGE_TIMEOUT", message: method + " timed out" } });
      }, timeoutMs || 60000);
      pending.set(id, { resolve: resolve, timer: timer });
      window.postMessage({ source: "ugow-bridge", nonce: nonce, kind: "rpc", id: id, method: method, params: params || {} }, window.location.origin);
    });
  }
  bus.callPage = callPage;

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (sender.id !== chrome.runtime.id || !message || typeof message !== "object") return false;
    if (message.type === "RPC" && typeof message.method === "string") {
      callPage(message.method, message.params, message.timeoutMs).then(sendResponse);
      return true; // async response
    }
    if (message.type === "FACTS") {
      bus.last.facts = message.facts;
      bus.emit("facts", message.facts);
      return false;
    }
    return false;
  });

  // Keep the service worker awake while WhatsApp Web is open so command
  // polling stays responsive; alarms recover it if it is stopped anyway.
  toWorker({ type: "PAGE_HELLO" });
  setInterval(function () { toWorker({ type: "KEEPALIVE" }); }, 20000);
})();
