// Command execution journal. An entry is written BEFORE WhatsApp is touched.
// States:
//   INTENT    provider id generated, EXECUTING not yet acknowledged by the
//             server. Nothing has been sent (send only follows the ack).
//   SENDING   server acknowledged EXECUTING; the send may or may not have
//             reached WhatsApp. After a crash this is resolved by looking
//             for the message id in WhatsApp Web — never by resending.
//   DONE_*    local outcome known; `reported` says whether the server has it.
export const JOURNAL_RETENTION_MS = 24 * 60 * 60 * 1000;

export function createJournal(table, { now = Date.now } = {}) {
  return {
    get: (commandId) => table.get(commandId),
    async put(entry) {
      await table.put({ ...entry, id: entry.commandId, updatedAt: now() });
    },
    async update(commandId, patch) {
      const row = await table.get(commandId);
      if (!row) return null;
      const next = { ...row, ...patch, updatedAt: now() };
      await table.put(next);
      return next;
    },
    delete: (commandId) => table.delete(commandId),
    all: () => table.all(),
    async findByProviderMessageId(providerMessageId) {
      if (!providerMessageId) return null;
      return (await table.allByIndex("providerMessageId", providerMessageId))[0] || null;
    },
    async prune() {
      const cutoff = now() - JOURNAL_RETENTION_MS;
      for (const row of await table.all()) {
        if (row.reported && row.updatedAt < cutoff) await table.delete(row.id);
      }
    }
  };
}
