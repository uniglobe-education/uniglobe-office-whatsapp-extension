// Durable event queue. Every observed event is written here before anything
// else happens, so a service-worker restart or network loss loses nothing.
//
// Records are partitioned by "<userId>:<accountId>:<bindingEpoch>" — the
// binding that observed them. Only the partition of the current, verified
// binding may be flushed. Anything else is quarantined: kept (bounded), shown
// in health, and replayed only if the same binding is restored. It is never
// sent under a different user, account or epoch.

export const DEFAULT_CAPACITY = 20000;
export const QUARANTINE_CAPACITY = 5000;
export const QUARANTINE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

export function partitionKey({ userId, accountId, bindingEpoch }) {
  return `${userId}:${accountId}:${bindingEpoch}`;
}

export function createEventStore(table, { capacity = DEFAULT_CAPACITY, quarantineCapacity = QUARANTINE_CAPACITY, now = Date.now } = {}) {
  const stats = { droppedFull: 0, droppedQuarantine: 0 };

  async function enqueue(partition, event, bytes) {
    const id = `${partition}|${event.eventKey}`;
    if (await table.get(id)) return { stored: true, duplicate: true };
    const count = await table.count();
    if (count >= capacity) {
      // Refuse rather than silently evicting unsent data; health reports it.
      stats.droppedFull += 1;
      return { stored: false, reason: "QUEUE_FULL" };
    }
    await table.put({ id, partition, eventKey: event.eventKey, event, bytes, createdAt: now(), attempts: 0, quarantined: false });
    return { stored: true, nearCapacity: count + 1 >= capacity * 0.8 };
  }

  async function pending(partition) {
    return (await table.all())
      .filter((row) => row.partition === partition && !row.quarantined)
      .sort((a, b) => a.createdAt - b.createdAt || (a.id < b.id ? -1 : 1));
  }

  async function remove(ids) {
    for (const id of ids) await table.delete(id);
  }

  async function bumpAttempts(ids) {
    for (const id of ids) {
      const row = await table.get(id);
      if (row) await table.put({ ...row, attempts: row.attempts + 1 });
    }
  }

  // Quarantine every record not belonging to `current` (null = quarantine all),
  // and release records that match it again (same binding restored).
  async function reconcilePartitions(current) {
    for (const row of await table.all()) {
      const shouldQuarantine = row.partition !== current;
      if (row.quarantined !== shouldQuarantine) await table.put({ ...row, quarantined: shouldQuarantine, quarantinedAt: shouldQuarantine ? now() : null });
    }
    await pruneQuarantine();
  }

  async function pruneQuarantine() {
    const quarantined = (await table.all()).filter((row) => row.quarantined).sort((a, b) => a.createdAt - b.createdAt);
    const cutoff = now() - QUARANTINE_MAX_AGE_MS;
    let excess = quarantined.length - quarantineCapacity;
    for (const row of quarantined) {
      if (row.createdAt < cutoff || excess > 0) {
        await table.delete(row.id);
        stats.droppedQuarantine += 1;
        excess -= 1;
      }
    }
  }

  async function counts(partition) {
    const rows = await table.all();
    return {
      pending: rows.filter((row) => !row.quarantined && row.partition === partition).length,
      quarantined: rows.filter((row) => row.quarantined).length,
      total: rows.length,
      capacity,
      droppedFull: stats.droppedFull,
      droppedQuarantine: stats.droppedQuarantine
    };
  }

  return { enqueue, pending, remove, bumpAttempts, reconcilePartitions, pruneQuarantine, counts };
}
