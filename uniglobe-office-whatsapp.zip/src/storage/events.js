// Durable event queue. Every observed event is written here before anything
// else happens, so a service-worker restart or network loss loses nothing.
//
// Records are partitioned by "<userId>:<accountId>:<bindingEpoch>" — the
// binding that observed them. Only the partition of the current, verified
// binding may be flushed. Anything else is quarantined: kept (bounded), shown
// in health, and replayed only if the same binding is restored. It is never
// sent under a different user, account or epoch.

export const DEFAULT_CAPACITY = 20000;
export const QUARANTINE_CAPACITY = 5000;
export const QUARANTINE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

export function partitionKey({ userId, accountId, bindingEpoch }) {
  return `${userId}:${accountId}:${bindingEpoch}`;
}

export function createEventStore(table, { capacity = DEFAULT_CAPACITY, quarantineCapacity = QUARANTINE_CAPACITY, now = Date.now } = {}) {
  const stats = { droppedFull: 0, droppedQuarantine: 0 };

  async function enqueue(partition, event, bytes) {
    const [result] = await enqueueMany(partition, [{ event, bytes }]);
    return result;
  }

  // Many events in one read + one write transaction. Refuses (never evicts)
  // once the queue is full; health reports it.
  async function enqueueMany(partition, items) {
    if (!items.length) return [];
    const ids = items.map(({ event }) => `${partition}|${event.eventKey}`);
    const existing = await table.getMany(ids);
    let count = await table.count();
    const results = [];
    const rows = [];
    const seen = new Set();
    const at = now();
    items.forEach(({ event, bytes }, i) => {
      if (existing[i] || seen.has(ids[i])) { results.push({ stored: true, duplicate: true }); return; }
      if (count >= capacity) { stats.droppedFull += 1; results.push({ stored: false, reason: "QUEUE_FULL" }); return; }
      seen.add(ids[i]);
      count += 1;
      rows.push({ id: ids[i], partition, eventKey: event.eventKey, event, bytes, createdAt: at, seq: i, attempts: 0, quarantined: false });
      results.push({ stored: true, nearCapacity: count >= capacity * 0.8 });
    });
    await table.putMany(rows);
    return results;
  }

  async function pending(partition) {
    return (await table.allByIndex("partition", partition))
      .filter((row) => !row.quarantined)
      .sort((a, b) => a.createdAt - b.createdAt || (a.seq ?? 0) - (b.seq ?? 0) || (a.id < b.id ? -1 : 1));
  }

  async function remove(ids) {
    await table.deleteMany(ids);
  }

  async function bumpAttempts(ids) {
    const rows = (await table.getMany(ids)).filter(Boolean);
    await table.putMany(rows.map((row) => ({ ...row, attempts: row.attempts + 1 })));
  }

  // Quarantine every record not belonging to `current` (null = quarantine all),
  // and release records that match it again (same binding restored).
  async function reconcilePartitions(current) {
    for (const row of await table.all()) {
      const shouldQuarantine = row.partition !== current;
      if (row.quarantined !== shouldQuarantine) await table.put({ ...row, quarantined: shouldQuarantine, quarantinedAt: shouldQuarantine ? now() : null });
    }
    await pruneQuarantine();
  }

  async function pruneQuarantine() {
    const quarantined = (await table.all()).filter((row) => row.quarantined).sort((a, b) => a.createdAt - b.createdAt);
    const cutoff = now() - QUARANTINE_MAX_AGE_MS;
    let excess = quarantined.length - quarantineCapacity;
    for (const row of quarantined) {
      if (row.createdAt < cutoff || excess > 0) {
        await table.delete(row.id);
        stats.droppedQuarantine += 1;
        excess -= 1;
      }
    }
  }

  async function counts(partition) {
    // The current partition is never quarantined (reconcilePartitions), so
    // both numbers come from counts, without reading the rows.
    const total = await table.count();
    const pendingCount = partition ? await table.countByIndex("partition", partition) : 0;
    return {
      pending: pendingCount,
      quarantined: total - pendingCount,
      total,
      capacity,
      droppedFull: stats.droppedFull,
      droppedQuarantine: stats.droppedQuarantine
    };
  }

  return { enqueue, enqueueMany, pending, remove, bumpAttempts, reconcilePartitions, pruneQuarantine, counts };
}
