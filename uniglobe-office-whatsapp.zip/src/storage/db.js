// Tiny table abstraction over the extension's own IndexedDB. The extension
// origin (chrome-extension://<id>) is not readable by content scripts or by
// WhatsApp Web, so queued student messages and credentials stay inside
// trusted extension contexts. Nothing here uses browser-synced storage.
//
// A "table" is { put, get, delete, all, clear, count }. The memory table has
// the same interface so queue logic is testable in Node.

const DB_NAME = "ugow";
const DB_VERSION = 1;
export const STORES = ["events", "media", "journal", "checkpoints", "diagnostics", "secrets", "kv"];

let dbPromise = null;

function promisify(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export function openDb(indexedDB = globalThis.indexedDB) {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const name of STORES) {
          if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, { keyPath: "id" });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  return dbPromise;
}

export function createIdbTable(storeName, indexedDB) {
  async function run(mode, fn) {
    const db = await openDb(indexedDB);
    const tx = db.transaction(storeName, mode);
    const result = await promisify(fn(tx.objectStore(storeName)));
    await new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
    return result;
  }
  return {
    put: (record) => run("readwrite", (s) => s.put(record)),
    get: (id) => run("readonly", (s) => s.get(id)),
    delete: (id) => run("readwrite", (s) => s.delete(id)),
    all: () => run("readonly", (s) => s.getAll()),
    clear: () => run("readwrite", (s) => s.clear()),
    count: () => run("readonly", (s) => s.count())
  };
}

export function createMemoryTable() {
  const rows = new Map();
  const clone = (value) => (value === undefined ? undefined : structuredClone(value));
  return {
    async put(record) { rows.set(record.id, clone(record)); return record.id; },
    async get(id) { return clone(rows.get(id)); },
    async delete(id) { rows.delete(id); },
    async all() { return [...rows.values()].map(clone); },
    async clear() { rows.clear(); },
    async count() { return rows.size; }
  };
}

// Small key/value helper on top of a table ({ id, value }).
export function createKv(table) {
  return {
    async get(key, fallback = null) { const row = await table.get(key); return row ? row.value : fallback; },
    async set(key, value) { await table.put({ id: key, value }); },
    async delete(key) { await table.delete(key); }
  };
}
