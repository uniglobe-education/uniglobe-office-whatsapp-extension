// Tiny table abstraction over the extension's own IndexedDB. The extension
// origin (chrome-extension://<id>) is not readable by content scripts or by
// WhatsApp Web, so queued student messages and credentials stay inside
// trusted extension contexts. Nothing here uses browser-synced storage.
//
// A "table" is { put, get, delete, all, clear, count }. The memory table has
// the same interface so queue logic is testable in Node.

const DB_NAME = "ugow";
// v2: indexes for the hot lookups (no more full-store scans) and `messages`,
// the extension's own local copy of every synced office message.
const DB_VERSION = 2;
export const STORES = ["events", "media", "journal", "checkpoints", "diagnostics", "secrets", "kv", "messages"];
export const INDEXES = {
  events: ["partition"],
  media: ["partition"],
  journal: ["providerMessageId"],
  messages: ["chatKey"]
};

let dbPromise = null;

function promisify(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export function openDb(indexedDB = globalThis.indexedDB) {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const name of STORES) {
          const store = db.objectStoreNames.contains(name)
            ? request.transaction.objectStore(name)
            : db.createObjectStore(name, { keyPath: "id" });
          for (const index of INDEXES[name] || []) {
            if (!store.indexNames.contains(index)) store.createIndex(index, index, { unique: false });
          }
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  return dbPromise;
}

export function createIdbTable(storeName, indexedDB) {
  async function run(mode, fn) {
    const db = await openDb(indexedDB);
    const tx = db.transaction(storeName, mode);
    const result = await promisify(fn(tx.objectStore(storeName)));
    await new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
    return result;
  }
  // Many operations in ONE transaction (one commit instead of one per row).
  async function runMany(mode, items, fn) {
    if (!items.length) return [];
    const db = await openDb(indexedDB);
    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);
    const results = await Promise.all(items.map((item) => promisify(fn(store, item))));
    await new Promise((resolve, reject) => {
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
    return results;
  }
  return {
    put: (record) => run("readwrite", (s) => s.put(record)),
    get: (id) => run("readonly", (s) => s.get(id)),
    delete: (id) => run("readwrite", (s) => s.delete(id)),
    all: () => run("readonly", (s) => s.getAll()),
    clear: () => run("readwrite", (s) => s.clear()),
    count: () => run("readonly", (s) => s.count()),
    putMany: (records) => runMany("readwrite", records, (s, record) => s.put(record)),
    getMany: (ids) => runMany("readonly", ids, (s, id) => s.get(id)),
    deleteMany: (ids) => runMany("readwrite", ids, (s, id) => s.delete(id)),
    allByIndex: (index, value) => run("readonly", (s) => s.index(index).getAll(IDBKeyRange.only(value))),
    countByIndex: (index, value) => run("readonly", (s) => s.index(index).count(IDBKeyRange.only(value)))
  };
}

export function createMemoryTable() {
  const rows = new Map();
  const clone = (value) => (value === undefined ? undefined : structuredClone(value));
  return {
    async put(record) { rows.set(record.id, clone(record)); return record.id; },
    async get(id) { return clone(rows.get(id)); },
    async delete(id) { rows.delete(id); },
    async all() { return [...rows.values()].map(clone); },
    async clear() { rows.clear(); },
    async count() { return rows.size; },
    async putMany(records) { for (const record of records) rows.set(record.id, clone(record)); return records.map((r) => r.id); },
    async getMany(ids) { return ids.map((id) => clone(rows.get(id))); },
    async deleteMany(ids) { for (const id of ids) rows.delete(id); },
    async allByIndex(index, value) { return [...rows.values()].filter((row) => row[index] === value).map(clone); },
    async countByIndex(index, value) { let n = 0; for (const row of rows.values()) if (row[index] === value) n += 1; return n; }
  };
}

// Small key/value helper on top of a table ({ id, value }).
export function createKv(table) {
  return {
    async get(key, fallback = null) { const row = await table.get(key); return row ? row.value : fallback; },
    async set(key, value) { await table.put({ id: key, value }); },
    async delete(key) { await table.delete(key); }
  };
}
