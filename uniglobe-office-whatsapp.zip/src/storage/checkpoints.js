// Per-chat sync coverage for one account. coveredFrom/coveredTo describe only
// the range the WhatsApp Web client actually exposed; reachedStart is set only
// when loading earlier messages returned nothing more.
export function createCheckpointStore(table) {
  const id = (accountId, streamKey) => `${accountId}|${streamKey}`;
  return {
    get: (accountId, streamKey) => table.get(id(accountId, streamKey)),
    async put(accountId, checkpoint) {
      await table.put({ ...checkpoint, id: id(accountId, checkpoint.streamKey), accountId, updatedAt: Date.now(), dirty: true });
    },
    async forAccount(accountId) {
      return (await table.all()).filter((row) => row.accountId === accountId);
    },
    async markClean(accountId, streamKeys) {
      for (const key of streamKeys) {
        const row = await table.get(id(accountId, key));
        if (row) await table.put({ ...row, dirty: false });
      }
    }
  };
}

// Protocol-shaped checkpoint for the events batch.
export function toWireCheckpoint(row) {
  return {
    streamKey: row.streamKey,
    generation: row.generation || 1,
    cursor: row.cursor || null,
    coveredFrom: row.coveredFrom || null,
    coveredTo: row.coveredTo || null,
    reachedStart: row.reachedStart === true,
    gap: row.gap || null
  };
}
