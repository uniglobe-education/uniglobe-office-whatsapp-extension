// Catch-up and reconciliation after (re)connecting.
//
// For every one-to-one chat the Web client lists (including chats nobody has
// opened), load messages back to:
//   - the chat's checkpoint minus a bounded overlap (reconnect), or
//   - historyDays ago (first enrollment of this account on this device).
// Messages older than the live watermark are sent in HISTORY mode (the server
// never turns those into fresh lead wins, unread counts or notifications);
// newer ones in RECONCILE mode. Coverage is recorded only for what the client
// actually exposed; `reachedStart` only when it had nothing earlier.
// `historyFloorMs` remembers how far back a chat was imported, so widening the
// history window later (e.g. importing all earlier chats) backfills chats that
// already have a checkpoint.
//
// Two passes, so the CRM fills up fast:
//   1. RECENT — every chat, newest first, only its last RECENT_DAYS (a couple
//      of page loads each, several chats at a time): every current student
//      and lead lands within minutes.
//   2. HISTORY — then one chat at a time, back to the history window, pausing
//      whenever live messages or CRM commands are waiting (`busy`).
export const OVERLAP_MS = 10 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;
export const RECENT_DAYS = 7;

export function createCatchUp({ rpc, checkpoints, enqueueEvents, accountId, historyDays, liveWatermarkMs, pilotStartedAt = () => null, chatAllowed = () => true, eventAllowed = () => true, busy = () => false, now = Date.now, maxChatsPerRun = 300, concurrency = 4, maxLoads = 20, recentLoads = 2, log = () => {} }) {
  const progress = { running: false, complete: false, pendingChats: null, lastRunAt: null, lastError: null, phase: null, recentTotal: 0, recentDone: 0, historyTotal: 0, historyDone: 0 };

  async function listAllChats() {
    const chats = [];
    let cursor = null;
    for (let page = 0; page < 50; page += 1) {
      const result = await rpc("listDirectChats", { cursor, limit: 200 });
      chats.push(...(result.chats || []));
      cursor = result.cursor;
      if (!cursor) break;
    }
    return chats;
  }

  function floorFor(watermark) {
    const pilotFloor = Date.parse(pilotStartedAt() || "");
    if (Number.isFinite(pilotFloor)) return pilotFloor;
    if (historyDays() === 0) return Number.isFinite(watermark) ? watermark : now();
    return now() - Math.max(1, historyDays()) * DAY_MS;
  }

  function needsBackfill(existing, floor) {
    if (!existing?.coveredTo || existing.reachedStart) return false;
    return !(Number.isFinite(existing.historyFloorMs) && existing.historyFloorMs <= floor);
  }

  async function syncChat(account, chat, watermark, { recent = false } = {}) {
    const existing = await checkpoints.get(account, chat.chatKey);
    const fullFloor = floorFor(watermark);
    // Recent pass on a never-synced chat: only its last few days for now; the
    // history pass comes back for the rest (the checkpoint keeps `more`).
    const recentFloor = Math.max(fullFloor, now() - RECENT_DAYS * DAY_MS);
    const shallow = recent && !existing?.coveredTo && recentFloor > fullFloor;
    const floor = shallow ? recentFloor : fullFloor;
    const backfill = !shallow && needsBackfill(existing, floor);
    const sinceMs = existing?.coveredTo ? Math.max(floor, Date.parse(existing.coveredTo) - OVERLAP_MS) : floor;
    // Nothing new since the last covered point: record coverage and move on.
    if (existing?.coveredTo && chat.lastMessageAtMs && chat.lastMessageAtMs < sinceMs && !existing.more && !backfill) return { chatKey: chat.chatKey, skipped: true };
    const fetchSince = existing?.more || backfill ? floor : sinceMs;
    // Reaching back past what is covered (a deep chat continuing, or a wider
    // history window): everything from coveredFrom onwards was already sent,
    // so only emit older messages (plus a small overlap). Without this every
    // pass re-sent the whole chat loaded so far.
    const covered = fetchSince === floor && existing?.coveredFrom ? Date.parse(existing.coveredFrom) : NaN;
    const emitBeforeMs = Number.isFinite(covered) ? covered + OVERLAP_MS : null;
    const result = await rpc("fetchMessages", { chatKey: chat.chatKey, sinceMs: fetchSince, historyBeforeMs: watermark, maxLoads: shallow ? recentLoads : maxLoads, emitBeforeMs }, { timeoutMs: 120000 });
    const selectedEvents = (result.events || []).filter(eventAllowed);
    if (selectedEvents.length) {
      const queued = await enqueueEvents(selectedEvents);
      // Invalid page events are dropped on purpose (and logged); only events
      // that were neither saved nor deliberately dropped block the checkpoint.
      if ((queued?.stored || 0) + (queued?.dropped || 0) !== selectedEvents.length) throw new Error("Catch-up events were not all saved; checkpoint was not advanced");
    }
    const coveredFrom = [existing?.coveredFrom, result.coveredFrom].filter(Boolean).map(Date.parse).sort((a, b) => a - b)[0];
    await checkpoints.put(account, {
      streamKey: chat.chatKey,
      generation: existing?.generation || 1,
      cursor: result.more ? "more" : null,
      coveredFrom: Number.isFinite(coveredFrom) ? new Date(coveredFrom).toISOString() : null,
      coveredTo: result.coveredTo || existing?.coveredTo || null,
      reachedStart: Boolean(existing?.reachedStart || result.reachedStart),
      // After a shallow pass the older history is still owed.
      more: Boolean(result.more || (shallow && !result.reachedStart)),
      historyFloorMs: !shallow && fetchSince === floor && !result.more ? floor : existing?.historyFloorMs ?? null,
      gap: result.more || (shallow && !result.reachedStart) ? "Older messages in the import window are still loading" : null
    });
    return { chatKey: chat.chatKey, events: result.events?.length || 0, more: Boolean(result.more || (shallow && !result.reachedStart)), shallow };
  }

  async function run() {
    if (progress.running) return progress;
    const account = accountId();
    if (!account) return progress;
    progress.running = true;
    try {
      const watermark = liveWatermarkMs();
      // listDirectChats is newest-first, so recent students land first.
      const chats = (await listAllChats()).filter(chatAllowed);
      let pending = 0;
      let chatError = null;
      const recentWork = [];
      const historyWork = [];
      for (const chat of chats) {
        const cp = await checkpoints.get(account, chat.chatKey);
        const backfill = needsBackfill(cp, floorFor(watermark));
        const newSinceCovered = !cp?.coveredTo || (chat.lastMessageAtMs && chat.lastMessageAtMs >= Date.parse(cp.coveredTo));
        if (newSinceCovered) recentWork.push(chat);
        else if (cp.more || backfill) historyWork.push(chat);
      }
      const runChat = async (chat, opts) => {
        try {
          const result = await syncChat(account, chat, watermark, opts);
          return result;
        } catch (error) {
          chatError = error.message || "catch-up failed";
          log("catch-up chat failed", chat.chatKey, chatError);
          return { failed: true };
        }
      };
      // 1) Recent pass: several chats at a time, a couple of page loads each.
      progress.phase = "RECENT";
      progress.recentTotal = recentWork.length;
      progress.recentDone = 0;
      const recentQueue = recentWork.slice(0, maxChatsPerRun);
      pending += recentWork.length - recentQueue.length;
      const lane = async () => {
        while (recentQueue.length) {
          const chat = recentQueue.shift();
          const result = await runChat(chat, { recent: true });
          progress.recentDone += 1;
          if (result.failed) pending += 1;
          else if (result.more) historyWork.push(chat);
        }
      };
      await Promise.all(Array.from({ length: Math.max(1, Math.min(concurrency, recentQueue.length)) }, lane));
      // 2) History pass: one chat at a time, giving way to live traffic.
      progress.phase = "HISTORY";
      progress.historyTotal = historyWork.length;
      progress.historyDone = 0;
      const seen = new Set();
      for (const chat of historyWork) {
        if (seen.has(chat.chatKey)) { progress.historyDone += 1; continue; }
        seen.add(chat.chatKey);
        if (busy()) { pending += historyWork.length - progress.historyDone; break; }
        const result = await runChat(chat, { recent: false });
        progress.historyDone += 1;
        if (result.failed || result.more) pending += 1;
      }
      progress.pendingChats = pending;
      progress.complete = pending === 0;
      progress.phase = progress.complete ? "DONE" : progress.phase;
      progress.lastError = chatError;
    } catch (error) {
      progress.lastError = error.message || "catch-up failed";
      progress.complete = false;
      log("catch-up failed", progress.lastError);
    } finally {
      progress.running = false;
      progress.lastRunAt = new Date(now()).toISOString();
    }
    return progress;
  }

  return { run, progress };
}
