// Catch-up and reconciliation after (re)connecting.
//
// For every one-to-one chat the Web client lists (including chats nobody has
// opened), load messages back to:
//   - the chat's checkpoint minus a bounded overlap (reconnect), or
//   - historyDays ago (first enrollment of this account on this device).
// Messages older than the live watermark are sent in HISTORY mode (the server
// never turns those into fresh lead wins, unread counts or notifications);
// newer ones in RECONCILE mode. Coverage is recorded only for what the client
// actually exposed; `reachedStart` only when it had nothing earlier.
// `historyFloorMs` remembers how far back a chat was imported, so widening the
// history window later (e.g. importing all earlier chats) backfills chats that
// already have a checkpoint.
export const OVERLAP_MS = 10 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

export function createCatchUp({ rpc, checkpoints, enqueueEvents, accountId, historyDays, liveWatermarkMs, pilotStartedAt = () => null, chatAllowed = () => true, eventAllowed = () => true, now = Date.now, maxChatsPerRun = 60, log = () => {} }) {
  const progress = { running: false, complete: false, pendingChats: null, lastRunAt: null, lastError: null };

  async function listAllChats() {
    const chats = [];
    let cursor = null;
    for (let page = 0; page < 50; page += 1) {
      const result = await rpc("listDirectChats", { cursor, limit: 200 });
      chats.push(...(result.chats || []));
      cursor = result.cursor;
      if (!cursor) break;
    }
    return chats;
  }

  function floorFor(watermark) {
    const pilotFloor = Date.parse(pilotStartedAt() || "");
    if (Number.isFinite(pilotFloor)) return pilotFloor;
    if (historyDays() === 0) return Number.isFinite(watermark) ? watermark : now();
    return now() - Math.max(1, historyDays()) * DAY_MS;
  }

  function needsBackfill(existing, floor) {
    if (!existing?.coveredTo || existing.reachedStart) return false;
    return !(Number.isFinite(existing.historyFloorMs) && existing.historyFloorMs <= floor);
  }

  async function syncChat(account, chat, watermark) {
    const existing = await checkpoints.get(account, chat.chatKey);
    const floor = floorFor(watermark);
    const backfill = needsBackfill(existing, floor);
    const sinceMs = existing?.coveredTo ? Math.max(floor, Date.parse(existing.coveredTo) - OVERLAP_MS) : floor;
    // Nothing new since the last covered point: record coverage and move on.
    if (existing?.coveredTo && chat.lastMessageAtMs && chat.lastMessageAtMs < sinceMs && !existing.more && !backfill) return { chatKey: chat.chatKey, skipped: true };
    const fetchSince = existing?.more || backfill ? floor : sinceMs;
    const result = await rpc("fetchMessages", { chatKey: chat.chatKey, sinceMs: fetchSince, historyBeforeMs: watermark, maxLoads: 5 }, { timeoutMs: 120000 });
    const selectedEvents = (result.events || []).filter(eventAllowed);
    if (selectedEvents.length) {
      const queued = await enqueueEvents(selectedEvents);
      // Invalid page events are dropped on purpose (and logged); only events
      // that were neither saved nor deliberately dropped block the checkpoint.
      if ((queued?.stored || 0) + (queued?.dropped || 0) !== selectedEvents.length) throw new Error("Catch-up events were not all saved; checkpoint was not advanced");
    }
    const coveredFrom = [existing?.coveredFrom, result.coveredFrom].filter(Boolean).map(Date.parse).sort((a, b) => a - b)[0];
    await checkpoints.put(account, {
      streamKey: chat.chatKey,
      generation: existing?.generation || 1,
      cursor: result.more ? "more" : null,
      coveredFrom: Number.isFinite(coveredFrom) ? new Date(coveredFrom).toISOString() : null,
      coveredTo: result.coveredTo || existing?.coveredTo || null,
      reachedStart: Boolean(existing?.reachedStart || result.reachedStart),
      more: Boolean(result.more),
      historyFloorMs: fetchSince === floor && !result.more ? floor : existing?.historyFloorMs ?? null,
      gap: result.more ? "Older messages in the import window are still loading" : null
    });
    return { chatKey: chat.chatKey, events: result.events?.length || 0, more: Boolean(result.more) };
  }

  async function run() {
    if (progress.running) return progress;
    const account = accountId();
    if (!account) return progress;
    progress.running = true;
    try {
      const watermark = liveWatermarkMs();
      const chats = (await listAllChats()).filter(chatAllowed);
      let pending = 0;
      let processed = 0;
      let chatError = null;
      for (const chat of chats) {
        const cp = await checkpoints.get(account, chat.chatKey);
        const fresh = cp?.coveredTo && !cp.more && !needsBackfill(cp, floorFor(watermark))
          && (!chat.lastMessageAtMs || chat.lastMessageAtMs < Date.parse(cp.coveredTo));
        if (fresh) continue;
        if (processed >= maxChatsPerRun) { pending += 1; continue; }
        processed += 1;
        // One chat that fails must not stop every other chat from importing;
        // it keeps its old checkpoint and is retried on the next run.
        try {
          const result = await syncChat(account, chat, watermark);
          if (result.more) pending += 1;
        } catch (error) {
          pending += 1;
          chatError = error.message || "catch-up failed";
          log("catch-up chat failed", chat.chatKey, chatError);
        }
      }
      progress.pendingChats = pending;
      progress.complete = pending === 0;
      progress.lastError = chatError;
    } catch (error) {
      progress.lastError = error.message || "catch-up failed";
      progress.complete = false;
      log("catch-up failed", progress.lastError);
    } finally {
      progress.running = false;
      progress.lastRunAt = new Date(now()).toISOString();
    }
    return progress;
  }

  return { run, progress };
}
