// Catch-up and reconciliation after (re)connecting.
//
// For every one-to-one chat the Web client lists (including chats nobody has
// opened), load messages back to:
//   - the chat's checkpoint minus a bounded overlap (reconnect), or
//   - historyDays ago (first enrollment of this account on this device).
// Messages older than the live watermark are sent in HISTORY mode (the server
// never turns those into fresh lead wins, unread counts or notifications);
// newer ones in RECONCILE mode. Coverage is recorded only for what the client
// actually exposed; `reachedStart` only when it had nothing earlier.
export const OVERLAP_MS = 10 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

export function createCatchUp({ rpc, checkpoints, enqueueEvents, accountId, historyDays, liveWatermarkMs, pilotStartedAt = () => null, chatAllowed = () => true, eventAllowed = () => true, now = Date.now, maxChatsPerRun = 60, log = () => {} }) {
  const progress = { running: false, complete: false, pendingChats: null, lastRunAt: null, lastError: null };

  async function listAllChats() {
    const chats = [];
    let cursor = null;
    for (let page = 0; page < 50; page += 1) {
      const result = await rpc("listDirectChats", { cursor, limit: 200 });
      chats.push(...(result.chats || []));
      cursor = result.cursor;
      if (!cursor) break;
    }
    return chats;
  }

  async function syncChat(account, chat, watermark) {
    const existing = await checkpoints.get(account, chat.chatKey);
    const pilotFloor = Date.parse(pilotStartedAt() || "");
    const floor = Number.isFinite(pilotFloor) ? pilotFloor : now() - Math.max(1, historyDays()) * DAY_MS;
    const sinceMs = existing?.coveredTo ? Math.max(floor, Date.parse(existing.coveredTo) - OVERLAP_MS) : floor;
    // Nothing new since the last covered point: record coverage and move on.
    if (existing?.coveredTo && chat.lastMessageAtMs && chat.lastMessageAtMs < sinceMs && !existing.more) return { chatKey: chat.chatKey, skipped: true };
    const result = await rpc("fetchMessages", { chatKey: chat.chatKey, sinceMs: existing?.more ? floor : sinceMs, historyBeforeMs: watermark, maxLoads: 5 }, { timeoutMs: 120000 });
    const selectedEvents = (result.events || []).filter(eventAllowed);
    if (selectedEvents.length) {
      const queued = await enqueueEvents(selectedEvents);
      if (queued?.stored !== selectedEvents.length) throw new Error("Catch-up events were not all saved; checkpoint was not advanced");
    }
    const coveredFrom = [existing?.coveredFrom, result.coveredFrom].filter(Boolean).map(Date.parse).sort((a, b) => a - b)[0];
    await checkpoints.put(account, {
      streamKey: chat.chatKey,
      generation: existing?.generation || 1,
      cursor: result.more ? "more" : null,
      coveredFrom: Number.isFinite(coveredFrom) ? new Date(coveredFrom).toISOString() : null,
      coveredTo: result.coveredTo || existing?.coveredTo || null,
      reachedStart: Boolean(existing?.reachedStart || result.reachedStart),
      more: Boolean(result.more),
      gap: result.more ? "Older messages in the import window are still loading" : null
    });
    return { chatKey: chat.chatKey, events: result.events?.length || 0, more: Boolean(result.more) };
  }

  async function run() {
    if (progress.running) return progress;
    const account = accountId();
    if (!account) return progress;
    progress.running = true;
    try {
      const watermark = liveWatermarkMs();
      const chats = (await listAllChats()).filter(chatAllowed);
      let pending = 0;
      let processed = 0;
      for (const chat of chats) {
        const cp = await checkpoints.get(account, chat.chatKey);
        const fresh = cp?.coveredTo && !cp.more && (!chat.lastMessageAtMs || chat.lastMessageAtMs < Date.parse(cp.coveredTo));
        if (fresh) continue;
        if (processed >= maxChatsPerRun) { pending += 1; continue; }
        const result = await syncChat(account, chat, watermark);
        processed += 1;
        if (result.more) pending += 1;
      }
      progress.pendingChats = pending;
      progress.complete = pending === 0;
      progress.lastError = null;
    } catch (error) {
      progress.lastError = error.message || "catch-up failed";
      progress.complete = false;
      log("catch-up failed", progress.lastError);
    } finally {
      progress.running = false;
      progress.lastRunAt = new Date(now()).toISOString();
    }
    return progress;
  }

  return { run, progress };
}
