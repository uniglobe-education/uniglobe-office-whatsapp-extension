// WhatsApp Web tab management.
//
// ensureWhatsAppTab: reuse any open web.whatsapp.com tab (never focus it —
// that would steal focus from the counselor); open one in the background only
// when none exists, at most once per CRM reconnect episode and never more than
// once per cooldown. Repeated CRM renders, several CRM tabs and flaky networks
// therefore cannot create a tab loop.
//
// Executor lease: when several WhatsApp tabs are open, exactly one (the most
// recently connected) captures events and executes commands.
export const WHATSAPP_URL = "https://web.whatsapp.com/";
export const WHATSAPP_MATCH = "https://web.whatsapp.com/*";
export const OPEN_COOLDOWN_MS = 5 * 60 * 1000;

export function createTabManager({ tabsApi, store, now = Date.now, cooldownMs = OPEN_COOLDOWN_MS }) {
  async function whatsappTabs() {
    return (await tabsApi.query({ url: WHATSAPP_MATCH })) || [];
  }

  async function ensureWhatsAppTab(episodeId) {
    const existing = await whatsappTabs();
    if (existing.length) return { ok: true, action: "EXISTING", tabId: existing[0].id };
    const memo = (await store.get("tabOpen")) || {};
    if ((episodeId && memo.episodeId === episodeId) || (typeof memo.at === "number" && now() - memo.at < cooldownMs)) {
      return { ok: true, action: "SKIPPED_RECENT" };
    }
    await store.set("tabOpen", { episodeId: episodeId || null, at: now() });
    const tab = await tabsApi.create({ url: WHATSAPP_URL, active: false });
    return { ok: true, action: "OPENED", tabId: tab?.id ?? null };
  }

  // Explicit user action (popup "Open WhatsApp", sidebar "Open chat"): focusing is fine.
  async function focusWhatsApp() {
    const existing = await whatsappTabs();
    if (existing.length) {
      await tabsApi.update(existing[0].id, { active: true });
      if (tabsApi.focusWindow && existing[0].windowId !== undefined) await tabsApi.focusWindow(existing[0].windowId);
      return existing[0].id;
    }
    const tab = await tabsApi.create({ url: WHATSAPP_URL, active: true });
    return tab?.id ?? null;
  }

  return { ensureWhatsAppTab, focusWhatsApp, whatsappTabs };
}

// Tracks WhatsApp tabs and their reported identity; picks the executor.
export function createTabRegistry({ now = Date.now } = {}) {
  const tabs = new Map(); // tabId -> { identity, seenAt, connectedAt }
  let executor = null;

  function update(tabId, identity) {
    const previous = tabs.get(tabId) || {};
    const connected = identity?.state === "CONNECTED";
    tabs.set(tabId, { identity, seenAt: now(), connectedAt: connected ? (previous.connectedAt || now()) : null });
    elect();
  }

  function touch(tabId) {
    const row = tabs.get(tabId);
    if (row) row.seenAt = now();
    else tabs.set(tabId, { identity: null, seenAt: now(), connectedAt: null });
  }

  function remove(tabId) {
    tabs.delete(tabId);
    elect();
  }

  function elect() {
    const current = executor !== null ? tabs.get(executor) : null;
    if (current && current.connectedAt) return executor;
    let best = null;
    for (const [tabId, row] of tabs) {
      if (row.connectedAt && (best === null || row.connectedAt > tabs.get(best).connectedAt)) best = tabId;
    }
    if (best === null) {
      // No connected tab: keep a loading/logged-out tab for identity display.
      for (const [tabId] of tabs) { best = tabId; break; }
    }
    executor = best;
    return executor;
  }

  return {
    update, touch, remove, elect,
    executor: () => executor,
    identity: () => (executor !== null ? tabs.get(executor)?.identity || null : null),
    ids: () => [...tabs.keys()],
    size: () => tabs.size
  };
}
