// Durable capture boundary. A caller may advance a catch-up checkpoint only
// after every selected event has reached the extension's persistent queue.
import { ProtocolError, eventAllowedInPilot, validateEvent } from "../lib/protocol.js";
import { byteLength } from "../lib/ids.js";
import { partitionKey } from "../storage/events.js";

// Local copy of a synced message: enough to know "already sent" without
// keeping student content longer than the CRM needs it.
function localRecord(accountId, event) {
  const message = event.message || {};
  return {
    id: `${accountId}|${event.providerMessageId}`,
    chatKey: event.chatKey,
    t: Date.parse(event.occurredAt) || null,
    direction: event.direction,
    kind: message.kind || null,
    hasMedia: Boolean(message.media),
    sig: `${message.kind || ""}|${(message.text || message.caption || "").length}|${(message.text || message.caption || "").slice(0, 48)}`,
    ack: null
  };
}

// History/reconcile passes re-read chats; anything already in the local copy
// with the same content (or an ack that is not newer) was already sent.
function alreadySynced(event, record) {
  if (!record || event.mode === "LIVE") return false;
  if (event.type === "MESSAGE_UPSERT") return record.sig === localRecord("", event).sig;
  if (event.type === "MESSAGE_ACK") return record.ack !== null && ackRank(event.ack) <= ackRank(record.ack);
  return false;
}
const ACK_ORDER = ["ERROR", "PENDING", "SENT", "DELIVERED", "READ", "PLAYED"];
const ackRank = (ack) => ACK_ORDER.indexOf(String(ack || ""));

export function createEventIngestor({ session, eventStore, tagEvent, diagnostics, scheduleFlush, messages = null, onStored = null }) {
  return async function ingestEvents(rawEvents, { fromCatchUp = false } = {}) {
    const binding = session.binding();
    if (!session.isActive() || !binding) {
      if (fromCatchUp) throw new Error("Office session became inactive before catch-up was saved");
      return { stored: 0, dropped: rawEvents.length };
    }
    const partition = partitionKey(binding);
    let stored = 0;
    let dropped = 0;
    try {
      const valid = [];
      for (const raw of rawEvents) {
        if (!session.isActive()) throw new Error("Office session became inactive during event capture");
        let event;
        try {
          event = validateEvent(await tagEvent(raw));
        } catch (error) {
          if (error instanceof ProtocolError) {
            await diagnostics.add({ kind: "PAGE_EVENT_INVALID", eventKey: typeof raw?.eventKey === "string" ? raw.eventKey.slice(0, 120) : null, type: typeof raw?.type === "string" ? raw.type.slice(0, 40) : null, error: error.message.slice(0, 200) });
            dropped += 1;
            continue;
          }
          throw error;
        }
        if (session.get()?.config?.pilotMode && !eventAllowedInPilot(event, session.get()?.config?.pilotContacts, session.get()?.account?.liveWatermark)) {
          dropped += 1;
          continue;
        }
        valid.push(event);
      }
      // Skip what the local copy says was already sent (catch-up re-reads).
      let fresh = valid;
      const records = new Map();
      if (messages && valid.length) {
        const ids = [...new Set(valid.filter((e) => e.providerMessageId).map((e) => `${binding.accountId}|${e.providerMessageId}`))];
        const found = await messages.getMany(ids);
        ids.forEach((id, i) => { if (found[i]) records.set(id, found[i]); });
        fresh = valid.filter((event) => {
          const skip = alreadySynced(event, records.get(`${binding.accountId}|${event.providerMessageId}`));
          if (skip) stored += 1;
          return !skip;
        });
      }
      const results = await eventStore.enqueueMany(partition, fresh.map((event) => ({ event, bytes: byteLength(event) })));
      const saved = fresh.filter((_, i) => results[i].stored);
      stored += saved.length;
      if (messages && saved.length) {
        const updates = new Map();
        for (const event of saved) {
          if (!event.providerMessageId) continue;
          const id = `${binding.accountId}|${event.providerMessageId}`;
          const current = updates.get(id) || records.get(id) || null;
          if (event.type === "MESSAGE_UPSERT") updates.set(id, { ...(current || {}), ...localRecord(binding.accountId, event), ack: current?.ack ?? null });
          else if (event.type === "MESSAGE_ACK" && current && ackRank(event.ack) > ackRank(current.ack)) updates.set(id, { ...current, ack: event.ack });
        }
        await messages.putMany([...updates.values()]);
      }
      // Files start copying now, in parallel with the text (not after it).
      if (onStored && saved.length) await Promise.resolve(onStored(partition, saved)).catch(() => {});
      const refused = results.find((result) => !result.stored);
      if (refused) throw new Error(`Office event queue refused an event: ${refused.reason || "UNKNOWN"}`);
      return { stored, dropped };
    } finally {
      // A new message goes out almost at once; catch-up batches can wait a little.
      if (stored) scheduleFlush(fromCatchUp ? 500 : 100);
    }
  };
}
