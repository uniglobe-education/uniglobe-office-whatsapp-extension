// Durable capture boundary. A caller may advance a catch-up checkpoint only
// after every selected event has reached the extension's persistent queue.
import { ProtocolError, eventAllowedInPilot, validateEvent } from "../lib/protocol.js";
import { byteLength } from "../lib/ids.js";
import { partitionKey } from "../storage/events.js";

export function createEventIngestor({ session, eventStore, tagEvent, diagnostics, scheduleFlush }) {
  return async function ingestEvents(rawEvents, { fromCatchUp = false } = {}) {
    const binding = session.binding();
    if (!session.isActive() || !binding) {
      if (fromCatchUp) throw new Error("Office session became inactive before catch-up was saved");
      return { stored: 0, dropped: rawEvents.length };
    }
    const partition = partitionKey(binding);
    let stored = 0;
    let dropped = 0;
    try {
      for (const raw of rawEvents) {
        if (!session.isActive()) throw new Error("Office session became inactive during event capture");
        let event;
        try {
          event = validateEvent(await tagEvent(raw));
        } catch (error) {
          if (error instanceof ProtocolError) {
            await diagnostics.add({ kind: "PAGE_EVENT_INVALID", eventKey: typeof raw?.eventKey === "string" ? raw.eventKey.slice(0, 120) : null, type: typeof raw?.type === "string" ? raw.type.slice(0, 40) : null, error: error.message.slice(0, 200) });
            dropped += 1;
            continue;
          }
          throw error;
        }
        if (session.get()?.config?.pilotMode && !eventAllowedInPilot(event, session.get()?.config?.pilotContacts, session.get()?.account?.liveWatermark)) {
          dropped += 1;
          continue;
        }
        const result = await eventStore.enqueue(partition, event, byteLength(event));
        if (!result.stored) throw new Error(`Office event queue refused an event: ${result.reason || "UNKNOWN"}`);
        stored += 1;
      }
      return { stored, dropped };
    } finally {
      if (stored) scheduleFlush();
    }
  };
}
