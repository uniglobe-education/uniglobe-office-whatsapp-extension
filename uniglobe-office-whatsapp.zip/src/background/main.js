// Service worker entry point: wires storage, session, outbox, media queue,
// command executor, catch-up and tab management to Chrome APIs.
//
// MV3 service workers stop when idle. Everything that matters is persisted
// (IndexedDB), a one-minute alarm restarts work, and the WhatsApp tab's
// bridge pings every 20 s so command polling stays responsive while
// WhatsApp Web is open. Scheduling is best-effort, not a delivery promise.
import { BUILD } from "../lib/build-config.js";
import { PROTOCOL_VERSION, isDirectChatKey, isUuid, eventAllowedInPilot, phoneFromChatKey } from "../lib/protocol.js";
import { isAllowedUrl } from "../lib/origins.js";
import { uuid } from "../lib/ids.js";
import { createIdbTable, createKv } from "../storage/db.js";
import { createEventStore, partitionKey } from "../storage/events.js";
import { createCheckpointStore, toWireCheckpoint } from "../storage/checkpoints.js";
import { createJournal } from "../storage/commands.js";
import { createApiClient } from "./api.js";
import { createSessionManager } from "./session.js";
import { createOutbox, createDiagnostics } from "./outbox.js";
import { createMediaQueue } from "./queue.js";
import { createCommandExecutor, wrapRpc } from "./commands.js";
import { createCatchUp } from "./catchup.js";
import { createEventIngestor } from "./ingest.js";
import { createTabManager, createTabRegistry, WHATSAPP_URL } from "./tabs.js";
import { createExternalHandler } from "./external.js";
import { createCallController } from "./calls.js";
import { buildFacts, heartbeatBody, redactedDiagnostics } from "./health.js";

const ALARM = "ugow-tick";
const FAST_POLL_MS = 2500;
const MAX_POLL_MS = 30000;

// ---- storage ---------------------------------------------------------------
const kv = createKv(createIdbTable("kv"));
const secrets = createIdbTable("secrets");
const eventStore = createEventStore(createIdbTable("events"));
const checkpoints = createCheckpointStore(createIdbTable("checkpoints"));
const journal = createJournal(createIdbTable("journal"));
const diagnostics = createDiagnostics(createIdbTable("diagnostics"));

// ---- runtime state -----------------------------------------------------------
const apiState = { reachable: null, lastSuccessAt: null, lastError: null };
const registry = createTabRegistry();
let instanceId = null;
let validated = false; // session re-validated with the server since worker start
let lastReportedIdentity = "";
let pollTimer = null;
let idlePolls = 0;
let flushTimer = null;

const session = createSessionManager({ build: BUILD, secrets, kv, onChange: () => broadcastFacts() });
const api = createApiClient({
  getBase: () => session.get()?.apiBase,
  getAccessToken: () => session.accessToken(),
  onReachability(ok, error) {
    apiState.reachable = ok;
    if (ok) apiState.lastSuccessAt = new Date().toISOString();
    apiState.lastError = ok ? null : error;
  }
});

async function rawRpc(method, params, options = {}) {
  const tabId = options.tabId ?? registry.executor();
  if (tabId === null) return { ok: false, error: { code: "NO_TAB", message: "WhatsApp Web is not open" } };
  try {
    return await chrome.tabs.sendMessage(tabId, { type: "RPC", method, params, timeoutMs: options.timeoutMs });
  } catch (error) {
    return { ok: false, error: { code: "NO_TAB", message: "WhatsApp Web tab is not reachable" } };
  }
}
const rpc = wrapRpc(rawRpc);
const calls = createCallController({
  store: kv, rpc, getExecutor: () => registry.executor(),
  authorize: (message) => api.request("/office-extension/calls/authorize", { body: { leadId: message.leadId } })
});

const tabManager = createTabManager({
  tabsApi: {
    query: (q) => chrome.tabs.query(q),
    create: (p) => chrome.tabs.create(p),
    update: (id, p) => chrome.tabs.update(id, p),
    focusWindow: (windowId) => chrome.windows.update(windowId, { focused: true })
  },
  store: kv
});

const capabilities = () => registry.identity()?.capabilities || {};
const mediaMaxBytes = () => Math.min(session.get()?.config?.mediaMaxBytes || 32 * 1024 * 1024, 32 * 1024 * 1024);

const executor = createCommandExecutor({
  api, journal, rpc,
  expectedPhone: () => session.get()?.account?.phoneE164 || null,
  capabilities,
  mediaOrigins: BUILD.mediaOrigins,
  maxMediaBytes: mediaMaxBytes,
  log: (...args) => console.warn("[ugow]", ...args)
});

const mediaQueue = createMediaQueue({ table: createIdbTable("media"), api, rpc, mediaOrigins: BUILD.mediaOrigins, maxBytes: mediaMaxBytes, diagnostics });

const outbox = createOutbox({
  eventStore, api, session, diagnostics,
  config: () => session.get()?.config || {},
  async checkpointsForFlush() {
    const accountId = session.get()?.accountId;
    if (!accountId) return [];
    return (await checkpoints.forAccount(accountId)).filter((row) => row.dirty
      && (!session.get()?.config?.pilotMode || phoneFromChatKey(row.streamKey))).slice(0, 100).map(toWireCheckpoint);
  },
  async markCheckpointsClean(keys) {
    const accountId = session.get()?.accountId;
    if (accountId) await checkpoints.markClean(accountId, keys);
  },
  async onAccepted(event) {
    const binding = session.binding();
    if (binding && event.type === "MESSAGE_UPSERT" && event.message?.media) await mediaQueue.enqueue(partitionKey(binding), event);
  },
  async onEpochMismatch() {
    // Admin rebound the account: our binding is stale. Re-pairing from the CRM
    // gets the new epoch; queued events stay under the old binding.
    await session.end("REVOKED");
    await eventStore.reconcilePartitions(null);
  }
});

function liveWatermarkMs() {
  const account = session.get()?.account;
  const server = account?.liveWatermark ? Date.parse(account.liveWatermark) : NaN;
  if (Number.isFinite(server)) return server;
  return localWatermark || Date.now();
}
let localWatermark = null;

const catchUp = createCatchUp({
  rpc, checkpoints,
  enqueueEvents: (events) => ingestEvents(events, { fromCatchUp: true }),
  accountId: () => session.get()?.accountId,
  historyDays: () => session.get()?.account?.historyDays ?? 30,
  liveWatermarkMs,
  pilotStartedAt: () => session.get()?.config?.pilotMode ? session.get()?.account?.liveWatermark : null,
  chatAllowed: (chat) => !session.get()?.config?.pilotMode || (Boolean(session.get()?.account?.liveWatermark)
    && session.get()?.config?.pilotContacts?.includes(phoneFromChatKey(chat.chatKey) || (chat.chatKey?.endsWith("@lid") ? chat.phoneE164 : null))),
  eventAllowed: (event) => !session.get()?.config?.pilotMode || eventAllowedInPilot(event, session.get()?.config?.pilotContacts, session.get()?.account?.liveWatermark),
  log: (...args) => console.warn("[ugow]", ...args)
});

// ---- facts -------------------------------------------------------------------
async function facts() {
  await session.load();
  const binding = session.binding();
  const counts = await eventStore.counts(binding ? partitionKey(binding) : null);
  const identity = registry.identity();
  return buildFacts({
    build: BUILD,
    instanceId,
    session: session.get(),
    tabIdentity: identity,
    api: apiState,
    queue: { events: counts.pending, media: await mediaQueue.depth(), quarantined: counts.quarantined, droppedFull: counts.droppedFull + mediaQueue.stats.droppedFull, capacity: counts.capacity },
    catchUp: { complete: catchUp.progress.complete, pendingChats: catchUp.progress.pendingChats, lastRunAt: catchUp.progress.lastRunAt },
    capabilities: identity?.capabilities || {},
    leaseValid: session.isActive() && identity?.state === "CONNECTED"
  });
}

async function broadcastFacts() {
  const current = await facts().catch(() => null);
  if (!current) return;
  for (const tabId of registry.ids()) chrome.tabs.sendMessage(tabId, { type: "FACTS", facts: current }).catch(() => {});
  chrome.action.setBadgeText({ text: badgeFor(current) }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ color: current.session.state === "ACTIVE" && current.whatsapp.state === "CONNECTED" ? "#0f766e" : "#b45309" }).catch(() => {});
}

function badgeFor(f) {
  if (!f.paired) return "";
  if (f.session.state === "MISMATCH") return "!";
  if (f.session.state !== "ACTIVE" || f.whatsapp.state !== "CONNECTED") return "…";
  return "";
}

// Only a verified binding captures; the pilot additionally filters every
// event before it reaches IndexedDB or the CRM API.
const ingestEvents = createEventIngestor({ session, eventStore, tagEvent: (event) => executor.tagEvent(event), diagnostics, scheduleFlush });

function scheduleFlush(delay = 500) {
  if (flushTimer) return;
  flushTimer = setTimeout(async () => {
    flushTimer = null;
    await syncNow();
  }, delay);
}

async function ensureValidated() {
  if (validated) return true;
  await session.load();
  if (!session.hasTokens()) return false;
  await heartbeat();
  return validated;
}

async function syncNow({ force = false } = {}) {
  if (!(await ensureValidated()) || !session.isActive()) return;
  if (session.get()?.config?.minExtensionVersion && (await facts()).outdated) return;
  await outbox.flush({ force });
  const binding = session.binding();
  if (binding && registry.identity()?.state === "CONNECTED") await mediaQueue.process(partitionKey(binding)).catch(() => {});
  broadcastFacts();
}

// ---- identity -------------------------------------------------------------------
async function onIdentity(tabId, identity) {
  registry.update(tabId, identity);
  const executorTab = registry.executor();
  for (const id of registry.ids()) {
    chrome.tabs.sendMessage(id, { type: "RPC", method: "setRole", params: { capture: id === executorTab } }).catch(() => {});
  }
  if (tabId !== executorTab) return;
  await session.load();
  const s = session.get();
  if (!s || ["REVOKED", "EXPIRED"].includes(s.state) || !session.hasTokens()) { broadcastFacts(); return; }
  const key = `${identity.state}|${identity.observedPhoneE164 || ""}`;
  if (key !== lastReportedIdentity || s.state === "PROVISIONAL") {
    lastReportedIdentity = key;
    try {
      await session.reportIdentity({ whatsappState: identity.state, observedPhoneE164: identity.observedPhoneE164 });
      validated = true;
    } catch (error) {
      await session.handleApiError(error);
    }
  }
  await afterSessionChange();
}

async function afterSessionChange() {
  const binding = session.binding();
  await eventStore.reconcilePartitions(session.isActive() && binding ? partitionKey(binding) : "__none__");
  if (session.isActive() && registry.identity()?.state === "CONNECTED") {
    const key = `watermark:${session.get().accountId}`;
    localWatermark = await kv.get(key, null);
    if (!localWatermark) { localWatermark = Date.now(); await kv.set(key, localWatermark); }
    await executor.reconcile().catch(() => {});
    catchUp.run().then(() => scheduleFlush(0));
    schedulePoll(0);
  }
  broadcastFacts();
}

// ---- commands --------------------------------------------------------------------
function schedulePoll(delay) {
  clearTimeout(pollTimer);
  pollTimer = setTimeout(pollCommands, delay);
}

async function pollCommands() {
  pollTimer = null;
  const ready = session.isActive() && registry.identity()?.state === "CONNECTED";
  if (!ready) return; // resumes on identity change or alarm
  try {
    if (!(await ensureValidated())) return;
    const { claimed } = await executor.claimAndRun({ max: 3 });
    idlePolls = claimed ? 0 : idlePolls + 1;
  } catch (error) {
    await session.handleApiError(error);
    idlePolls += 1;
  }
  // 2.5 s while active; after a minute without commands back off to 30 s.
  const delay = idlePolls < 24 ? FAST_POLL_MS : Math.min(MAX_POLL_MS, Math.round(FAST_POLL_MS * 1.5 ** (idlePolls - 23)));
  if (session.isActive()) schedulePoll(delay);
}

// ---- heartbeat -----------------------------------------------------------------------
async function heartbeat() {
  await session.load();
  if (!session.hasTokens()) return;
  const current = await facts();
  try {
    const response = await api.request("/office-extension/heartbeat", { body: heartbeatBody(current, outbox.state) });
    session.updateFromServer(response);
    validated = true;
    if (response.pendingCommands > 0) { idlePolls = 0; schedulePoll(0); }
  } catch (error) {
    await session.handleApiError(error);
  }
  broadcastFacts();
}

async function tick() {
  await session.load();
  if (!instanceId) instanceId = await ensureInstanceId();
  if (!session.hasTokens()) return;
  await heartbeat();
  await syncNow();
  if (session.isActive()) {
    await executor.reconcile().catch(() => {});
    if (!pollTimer) schedulePoll(0);
    if (!catchUp.progress.complete && registry.identity()?.state === "CONNECTED") catchUp.run().then(() => scheduleFlush(0));
  }
  await eventStore.pruneQuarantine();
}

async function ensureInstanceId() {
  let id = await kv.get("instanceId", null);
  if (!id) { id = uuid(); await kv.set("instanceId", id); }
  return id;
}

// ---- CRM page (external) messages -------------------------------------------------------
async function callBinding(message, origin) {
  await session.load();
  const current = session.get();
  if (!current || current.crmOrigin !== origin || current.accountId !== message.accountId || current.userId !== message.crmUserId) {
    throw Object.assign(new Error("Connect your own office WhatsApp before calling"), { code: "CALL_BINDING_MISMATCH" });
  }
  if (!isUuid(message.callId)) throw Object.assign(new Error("Invalid call id"), { code: "INVALID_CALL" });
  return current;
}
const handleExternal = createExternalHandler({
  allowedOrigins: BUILD.crmOrigins,
  handlers: {
    async PING() {
      return { ok: true, extensionVersion: BUILD.version, protocolVersion: PROTOCOL_VERSION, instanceId: instanceId || (instanceId = await ensureInstanceId()) };
    },
    async STATUS() {
      return { ok: true, facts: await facts() };
    },
    async PAIR(message, { origin }) {
      instanceId = instanceId || await ensureInstanceId();
      await session.pair({ challenge: message.challenge, apiBase: message.apiBase, accountId: message.accountId, crmUserId: message.crmUserId, crmOrigin: origin, instanceId });
      validated = true;
      lastReportedIdentity = "";
      const identity = registry.identity();
      if (identity) await onIdentity(registry.executor(), identity);
      else await afterSessionChange();
      return { ok: true, facts: await facts() };
    },
    async ENSURE_WHATSAPP_TAB(message) {
      const episodeId = typeof message.episodeId === "string" ? message.episodeId.slice(0, 100) : null;
      return tabManager.ensureWhatsAppTab(episodeId);
    },
    async OPEN_CHAT(message) {
      if (!isDirectChatKey(message.chatKey)) return { ok: false, error: "INVALID_CHAT" };
      await rpc("openChat", { chatKey: message.chatKey });
      const tabId = registry.executor();
      if (tabId !== null) {
        const tab = await chrome.tabs.update(tabId, { active: true });
        if (tab.windowId !== undefined) await chrome.windows.update(tab.windowId, { focused: true });
      }
      return { ok: true };
    },
    async START_CALL(message, { origin }) {
      await callBinding(message, origin);
      if (!session.isActive() || !isUuid(message.leadId)) throw Object.assign(new Error("Reconnect your office WhatsApp"), { code: "SESSION_NOT_ACTIVE" });
      const call = await calls.run("START_CALL", message, origin);
      return { ok: true, call };
    },
    async CALL_STATUS(message, { origin }) {
      await callBinding(message, origin);
      return { ok: true, call: await calls.run("CALL_STATUS", message, origin) };
    },
    async END_CALL(message, { origin }) {
      await callBinding(message, origin);
      return { ok: true, call: await calls.run("END_CALL", message, origin) };
    },
    async LOGOUT(message) {
      await session.load();
      const current = session.get();
      if (current && message.crmUserId && current.userId !== message.crmUserId) return { ok: true, ignored: true };
      await session.logout({ remote: true });
      await eventStore.reconcilePartitions("__none__");
      clearTimeout(pollTimer);
      pollTimer = null;
      broadcastFacts();
      return { ok: true };
    }
  }
});

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  handleExternal(message, sender).then(sendResponse);
  return true;
});

// ---- content scripts and extension pages ----------------------------------------------------
const SIDEBAR_ACTIONS = new Set(["NOTE", "STATUS", "FOLLOW_UP", "COMPLETE_FOLLOW_UP", "CLASSIFY"]);
const CLASSIFY_CATEGORIES = new Set(["TEAMMATE", "PARTNER", "OTHER", "STUDENT"]);

function cleanAction(action) {
  if (!action || typeof action !== "object" || !SIDEBAR_ACTIONS.has(action.action)) return null;
  const s = (value, max) => (typeof value === "string" ? value.slice(0, max) : null);
  return {
    action: action.action,
    body: s(action.body, 4000),
    status: s(action.status, 60),
    dueAt: s(action.dueAt, 40),
    note: s(action.note, 1000),
    followUpId: s(action.followUpId, 40),
    category: CLASSIFY_CATEGORIES.has(action.category) ? action.category : null
  };
}

async function sidebarContext(chatKey) {
  if (!session.isActive()) return { ok: false, error: "Not connected to the CRM" };
  if (!isDirectChatKey(chatKey)) return { ok: false, error: "Not a one-to-one chat" };
  try {
    const context = await api.request(`/office-extension/chats/${encodeURIComponent(chatKey)}/context`, { method: "GET" });
    if (context.crmUrl && !isAllowedUrl(context.crmUrl, BUILD.crmOrigins)) context.crmUrl = null;
    return { ok: true, context };
  } catch (error) {
    await session.handleApiError(error);
    return { ok: false, error: error.network ? "CRM is not reachable right now" : error.message };
  }
}

async function sidebarAction(chatKey, raw) {
  const action = cleanAction(raw);
  if (!action || !session.isActive() || !isDirectChatKey(chatKey)) return { ok: false, error: "Action not allowed" };
  try {
    await api.request(`/office-extension/chats/${encodeURIComponent(chatKey)}/actions`, { body: action });
    return { ok: true };
  } catch (error) {
    await session.handleApiError(error);
    return { ok: false, error: error.network ? "CRM is not reachable right now" : error.message };
  }
}

function fromWhatsAppTab(sender) {
  return sender.id === chrome.runtime.id && sender.tab && sender.frameId === 0 && typeof sender.url === "string" && sender.url.startsWith(WHATSAPP_URL);
}

function fromExtensionPage(sender) {
  return sender.id === chrome.runtime.id && !sender.tab && typeof sender.url === "string" && sender.url.startsWith(chrome.runtime.getURL(""));
}

async function exportDiagnostics() {
  const current = await facts();
  let selfTest = null;
  try { selfTest = await rpc("selfTest", {}); } catch { /* no tab */ }
  return redactedDiagnostics(current, await diagnostics.all(), selfTest);
}

async function handleInternal(message, sender) {
  if (!message || typeof message !== "object") return { ok: false };
  if (fromWhatsAppTab(sender)) {
    const tabId = sender.tab.id;
    switch (message.type) {
      case "PAGE_HELLO":
      case "KEEPALIVE":
        registry.touch(tabId);
        if (message.type === "PAGE_HELLO") broadcastFacts();
        return { ok: true };
      case "PAGE_IDENTITY":
        await onIdentity(tabId, sanitizeIdentity(message.identity));
        return { ok: true };
      case "PAGE_EVENTS":
        if (tabId !== registry.executor() || !Array.isArray(message.events)) return { ok: false };
        return { ok: true, ...(await ingestEvents(message.events)) };
      case "GET_FACTS":
        return { ok: true, facts: await facts() };
      case "SIDEBAR_CONTEXT":
        return sidebarContext(message.chatKey);
      case "SIDEBAR_ACTION":
        return sidebarAction(message.chatKey, message.action);
      default:
        return { ok: false };
    }
  }
  if (fromExtensionPage(sender)) {
    switch (message.type) {
      case "GET_FACTS":
        return { ok: true, facts: await facts() };
      case "RETRY_SYNC":
        await syncNow({ force: true });
        if (session.isActive()) catchUp.run().then(() => scheduleFlush(0));
        return { ok: true, facts: await facts() };
      case "OPEN_WHATSAPP":
        await tabManager.focusWhatsApp();
        return { ok: true };
      case "OPEN_CRM": {
        const origin = session.get()?.crmOrigin || BUILD.crmOrigins[0];
        await chrome.tabs.create({ url: `${origin}/`, active: true });
        return { ok: true };
      }
      case "EXPORT_DIAGNOSTICS":
        return { ok: true, diagnostics: await exportDiagnostics() };
      default:
        return { ok: false };
    }
  }
  return { ok: false };
}

// Page-reported identity is untrusted: keep only well-formed fields.
function sanitizeIdentity(identity) {
  const states = ["LOADING", "LOGGED_OUT", "CONNECTED", "ADAPTER_ERROR"];
  const phone = typeof identity?.observedPhoneE164 === "string" && /^\+[1-9]\d{6,14}$/.test(identity.observedPhoneE164) ? identity.observedPhoneE164 : null;
  const caps = {};
  if (identity?.capabilities && typeof identity.capabilities === "object") {
    for (const [key, value] of Object.entries(identity.capabilities)) if (typeof value === "boolean" && key.length < 40) caps[key] = value;
  }
  return {
    state: states.includes(identity?.state) ? identity.state : "LOADING",
    observedPhoneE164: phone,
    adapterVersion: typeof identity?.adapterVersion === "string" ? identity.adapterVersion.slice(0, 64) : null,
    adapterError: typeof identity?.adapterError === "string" ? identity.adapterError.slice(0, 200) : null,
    capabilities: caps
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleInternal(message, sender).then(sendResponse, () => sendResponse({ ok: false }));
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  registry.remove(tabId);
  broadcastFacts();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) tick().catch((error) => console.warn("[ugow] tick failed", error.message));
});

chrome.runtime.onInstalled.addListener(() => chrome.alarms.create(ALARM, { periodInMinutes: 1 }));
chrome.runtime.onStartup.addListener(() => {
  validated = false; // browser restart: re-validate before replay or send
  chrome.alarms.create(ALARM, { periodInMinutes: 1 });
});

// Worker (re)start.
(async () => {
  chrome.alarms.get(ALARM).then((alarm) => { if (!alarm) chrome.alarms.create(ALARM, { periodInMinutes: 1 }); }).catch(() => {});
  instanceId = await ensureInstanceId();
  await session.load();
  // Existing WhatsApp tabs announce themselves via KEEPALIVE; ask them now.
  const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" }).catch(() => []);
  for (const tab of tabs) {
    registry.touch(tab.id);
    chrome.tabs.sendMessage(tab.id, { type: "RPC", method: "getIdentity", params: {} })
      .then((reply) => { if (reply?.ok) onIdentity(tab.id, sanitizeIdentity(reply.result)); })
      .catch(() => {});
  }
  tick().catch(() => {});
})();
