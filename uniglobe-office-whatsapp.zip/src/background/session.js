// Pairing, identity verification, token refresh and logout.
//
// Credentials live in the extension's IndexedDB "secrets" table (the
// extension origin — not reachable from content scripts or WhatsApp Web) and
// in memory. Nothing is stored in browser-synced storage.
import { PROTOCOL_VERSION, ERROR_CODES } from "../lib/protocol.js";
import { isAllowedOrigin, originOf } from "../lib/origins.js";
import { ApiError, FATAL_SESSION_CODES } from "./api.js";

const REFRESH_MARGIN_MS = 2 * 60 * 1000;

export function createSessionManager({ build, secrets, kv, fetchImpl = (...a) => fetch(...a), now = Date.now, onChange = () => {} }) {
  let state = null; // { id, state, apiBase, accountId, userId, account, config, expiresAt, maxExpiresAt, crmOrigin }
  let tokens = null; // { accessToken, accessExpiresAt, refreshToken }
  let refreshing = null;
  let loaded = false;

  async function load() {
    if (loaded) return state;
    state = await kv.get("session", null);
    const row = await secrets.get("tokens");
    tokens = row ? row.value : null;
    loaded = true;
    return state;
  }

  async function persist() {
    await kv.set("session", state);
    if (tokens) await secrets.put({ id: "tokens", value: tokens });
    else await secrets.delete("tokens");
    onChange(state);
  }

  async function post(path, body, { auth = true, base = null } = {}) {
    const headers = { "content-type": "application/json" };
    if (auth) headers.authorization = `Bearer ${await accessToken()}`;
    let response;
    try {
      response = await fetchImpl(`${base || state?.apiBase}${path}`, { method: "POST", headers, body: JSON.stringify(body || {}), credentials: "omit", cache: "no-store" });
    } catch (error) {
      throw new ApiError("CRM API unreachable", { network: true });
    }
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new ApiError(payload.error || `HTTP ${response.status}`, { status: response.status, code: payload.details?.code || null });
    return payload;
  }

  function adopt(payload, apiBase, crmOrigin) {
    state = {
      id: payload.session.id,
      state: payload.session.state,
      expiresAt: payload.session.expiresAt || null,
      maxExpiresAt: payload.session.maxExpiresAt || null,
      apiBase,
      crmOrigin,
      accountId: payload.account?.id,
      userId: payload.user?.id,
      userName: payload.user?.name || null,
      account: payload.account || null,
      config: payload.config || {}
    };
    tokens = { accessToken: payload.accessToken, accessExpiresAt: Date.parse(payload.accessExpiresAt) || now() + 10 * 60 * 1000, refreshToken: payload.refreshToken };
  }

  // PAIR from the CRM page. apiBase is checked against the build allowlist so
  // a page cannot point the extension at another server.
  async function pair({ challenge, apiBase, accountId, crmUserId, crmOrigin, instanceId }) {
    await load();
    const base = originOf(apiBase);
    if (!base || !isAllowedOrigin(base, build.apiBases)) throw new ApiError("API address not allowed", { code: "API_NOT_ALLOWED" });
    if (typeof challenge !== "string" || challenge.length < 16 || challenge.length > 200) throw new ApiError("Invalid pairing challenge", { code: ERROR_CODES.PAIRING_INVALID });
    // A different CRM user pairing this browser ends the previous session first.
    if (state && state.userId && crmUserId && state.userId !== crmUserId) await logout({ remote: true });
    const payload = await post("/office-extension/pair", {
      challenge, instanceId, extensionVersion: build.version, protocolVersion: PROTOCOL_VERSION
    }, { auth: false, base });
    if (accountId && payload.account?.id !== accountId) throw new ApiError("Paired account differs from the requested one", { code: ERROR_CODES.ACCOUNT_MISMATCH });
    adopt(payload, base, crmOrigin || null);
    await persist();
    return state;
  }

  async function accessToken() {
    await load();
    if (!tokens) return null;
    if (tokens.accessExpiresAt - now() < REFRESH_MARGIN_MS) await refresh();
    return tokens?.accessToken || null;
  }

  async function refresh() {
    if (refreshing) return refreshing;
    refreshing = (async () => {
      try {
        if (!tokens?.refreshToken || !state?.apiBase) return;
        const payload = await post("/office-extension/refresh", { refreshToken: tokens.refreshToken }, { auth: false });
        adopt(payload, state.apiBase, state.crmOrigin);
        await persist();
      } catch (error) {
        if (error instanceof ApiError && !error.network && (error.status === 401 || FATAL_SESSION_CODES.has(error.code))) await end(error.code === ERROR_CODES.SESSION_EXPIRED ? "EXPIRED" : "REVOKED");
        throw error;
      } finally {
        refreshing = null;
      }
    })();
    return refreshing;
  }

  // Reports what WhatsApp Web shows. The server decides ACTIVE vs MISMATCH.
  async function reportIdentity({ whatsappState, observedPhoneE164 }) {
    await load();
    if (!state || ["REVOKED", "EXPIRED"].includes(state.state)) return state;
    const payload = await post("/office-extension/identity", { whatsappState, observedPhoneE164: observedPhoneE164 || null });
    state = { ...state, state: payload.session?.state || state.state, expiresAt: payload.session?.expiresAt || state.expiresAt, account: payload.account || state.account };
    await persist();
    return state;
  }

  // Session is unusable: stop everything. Tokens are dropped; queued events
  // stay quarantined under their original binding.
  async function end(finalState) {
    await load();
    if (state) state = { ...state, state: finalState };
    tokens = null;
    await persist();
  }

  async function logout({ remote = true } = {}) {
    await load();
    if (remote && state && tokens && !["REVOKED", "EXPIRED"].includes(state.state)) {
      try { await post("/office-extension/logout", {}); } catch { /* revoked server-side on CRM logout too */ }
    }
    state = null;
    tokens = null;
    await persist();
  }

  async function handleApiError(error) {
    if (!(error instanceof ApiError) || error.network) return false;
    if (FATAL_SESSION_CODES.has(error.code) || (error.status === 401 && error.code !== ERROR_CODES.SESSION_NOT_ACTIVE)) {
      await end(error.code === ERROR_CODES.SESSION_EXPIRED ? "EXPIRED" : "REVOKED");
      return true;
    }
    if (error.code === ERROR_CODES.ACCOUNT_MISMATCH && state) {
      state = { ...state, state: "MISMATCH" };
      await persist();
      return true;
    }
    return false;
  }

  function isActive() {
    return Boolean(state && tokens && state.state === "ACTIVE");
  }

  function binding() {
    if (!state?.userId || !state?.accountId || !state?.account?.bindingEpoch) return null;
    return { userId: state.userId, accountId: state.accountId, bindingEpoch: state.account.bindingEpoch };
  }

  function updateFromServer(payload) {
    if (!state || !payload) return;
    state = {
      ...state,
      state: payload.session?.state || state.state,
      expiresAt: payload.session?.expiresAt || state.expiresAt,
      account: payload.account || state.account
    };
    persist();
  }

  return {
    load, pair, refresh, reportIdentity, logout, end, accessToken, handleApiError, isActive, binding, updateFromServer,
    get: () => state,
    hasTokens: () => Boolean(tokens)
  };
}
