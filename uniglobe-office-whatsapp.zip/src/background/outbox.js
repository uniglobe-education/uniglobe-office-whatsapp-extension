// Flushes the durable event queue to POST /office-extension/events.
// Only the current verified binding's partition is ever sent (see
// storage/events.js). ACCEPTED and DUPLICATE results are durable on the
// server and are removed locally; REJECTED results are permanent and are
// moved to diagnostics (no message content kept); anything else stays queued.
import { PROTOCOL_VERSION, LIMITS, ERROR_CODES } from "../lib/protocol.js";
import { computeBackoff } from "../lib/backoff.js";
import { byteLength, uuid } from "../lib/ids.js";
import { partitionKey } from "../storage/events.js";
import { ApiError } from "./api.js";

const ENVELOPE_BYTES = 2048;

// Picks the oldest records that fit both limits. Returns { batch, oversized }.
export function selectBatch(records, { maxEvents = LIMITS.batchEvents, maxBytes = LIMITS.batchBytes, reservedBytes = ENVELOPE_BYTES } = {}) {
  const batch = [];
  const oversized = [];
  let bytes = reservedBytes;
  for (const record of records) {
    if (batch.length >= maxEvents) break;
    const size = (record.bytes || byteLength(record.event)) + 1;
    if (size + reservedBytes > maxBytes) { oversized.push(record); continue; }
    if (bytes + size > maxBytes) break;
    batch.push(record);
    bytes += size;
  }
  return { batch, oversized, bytes };
}

export function createDiagnostics(table, { cap = 200, now = Date.now } = {}) {
  return {
    async add(entry) {
      await table.put({ id: `${now()}-${Math.random().toString(36).slice(2, 8)}`, at: new Date(now()).toISOString(), ...entry });
      const all = (await table.all()).sort((a, b) => (a.id < b.id ? -1 : 1));
      for (const row of all.slice(0, Math.max(0, all.length - cap))) await table.delete(row.id);
    },
    all: () => table.all()
  };
}

export function createOutbox({ eventStore, api, session, diagnostics, checkpointsForFlush = async () => [], markCheckpointsClean = async () => {}, onAccepted = async () => {}, onEpochMismatch = async () => {}, now = Date.now, random = Math.random, config = () => ({}) }) {
  const state = { attempt: 0, nextAttemptAt: 0, lastFlushAt: null, lastError: null, flushing: null };

  // `cache` keeps the pending list across the batches of one flush, so the
  // queue is read once per flush instead of once per batch.
  async function flushOnce(cache) {
    const binding = session.binding();
    if (!session.isActive() || !binding) return { sent: 0, stopped: "INACTIVE" };
    const partition = partitionKey(binding);
    const cfg = config();
    if (!cache.records || cache.partition !== partition) {
      cache.records = await eventStore.pending(partition);
      cache.partition = partition;
    }
    const records = cache.records;
    const { batch, oversized } = selectBatch(records, { maxEvents: Math.min(cfg.batchMaxEvents || LIMITS.batchEvents, LIMITS.batchEvents), maxBytes: Math.min(cfg.batchMaxBytes || LIMITS.batchBytes, LIMITS.batchBytes) });
    for (const record of oversized) {
      await diagnostics.add({ kind: "EVENT_TOO_LARGE", eventKey: record.eventKey, type: record.event?.type || null });
      await eventStore.remove([record.id]);
    }
    if (oversized.length) {
      const gone = new Set(oversized.map((r) => r.id));
      cache.records = records.filter((r) => !gone.has(r.id));
    }
    const checkpoints = await checkpointsForFlush();
    if (!batch.length && !checkpoints.length) return { sent: 0, done: true };
    const body = { protocolVersion: PROTOCOL_VERSION, batchId: uuid(), bindingEpoch: binding.bindingEpoch, events: batch.map((r) => r.event), checkpoints: checkpoints.slice(0, LIMITS.checkpoints) };
    let response;
    try {
      response = await api.request("/office-extension/events", { body });
    } catch (error) {
      if (error instanceof ApiError && error.code === ERROR_CODES.EPOCH_MISMATCH) {
        await onEpochMismatch();
        return { sent: 0, stopped: "EPOCH_MISMATCH" };
      }
      if (await session.handleApiError(error)) return { sent: 0, stopped: "SESSION" };
      await eventStore.bumpAttempts(batch.map((r) => r.id));
      throw error;
    }
    const byKey = new Map((response.results || []).map((r) => [r.eventKey, r]));
    const done = [];
    let accepted = 0;
    let rejected = 0;
    for (const record of batch) {
      const result = byKey.get(record.eventKey);
      if (!result) continue;
      if (result.status === "ACCEPTED" || result.status === "DUPLICATE") {
        done.push(record.id);
        accepted += 1;
        await onAccepted(record.event, result);
      } else if (result.status === "REJECTED") {
        done.push(record.id);
        rejected += 1;
        await diagnostics.add({ kind: "EVENT_REJECTED", eventKey: record.eventKey, type: record.event?.type || null, error: String(result.error || "").slice(0, 300) });
      }
    }
    await eventStore.remove(done);
    if (checkpoints.length) await markCheckpointsClean(checkpoints.map((c) => c.streamKey));
    const finished = new Set(done);
    const unanswered = batch.some((record) => !finished.has(record.id));
    cache.records = cache.records.filter((r) => !finished.has(r.id));
    // An unanswered event stays queued; re-read next flush rather than loop on it.
    if (unanswered) cache.records = null;
    return { sent: batch.length, accepted, rejected, done: unanswered || !cache.records || cache.records.length === 0 };
  }

  async function flush({ force = false, maxBatches = 60 } = {}) {
    if (state.flushing) return state.flushing;
    if (!force && now() < state.nextAttemptAt) return { skipped: "BACKOFF" };
    state.flushing = (async () => {
      const totals = { sent: 0, accepted: 0, rejected: 0 };
      try {
        const cache = {};
        for (let i = 0; i < maxBatches; i += 1) {
          const result = await flushOnce(cache);
          totals.sent += result.sent || 0;
          totals.accepted += result.accepted || 0;
          totals.rejected += result.rejected || 0;
          if (result.stopped) return { ...totals, stopped: result.stopped };
          if (result.done || !result.sent) break;
        }
        state.attempt = 0;
        state.nextAttemptAt = 0;
        state.lastFlushAt = new Date(now()).toISOString();
        state.lastError = null;
        return totals;
      } catch (error) {
        state.attempt += 1;
        state.nextAttemptAt = now() + computeBackoff(state.attempt, { random });
        state.lastError = error.message || "flush failed";
        return { ...totals, error: state.lastError, retryAt: state.nextAttemptAt };
      } finally {
        state.flushing = null;
      }
    })();
    return state.flushing;
  }

  return { flush, state, partition: () => (session.binding() ? partitionKey(session.binding()) : null) };
}
