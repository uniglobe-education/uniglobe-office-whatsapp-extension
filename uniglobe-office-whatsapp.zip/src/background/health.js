// Connection facts (protocol.md §1) and redacted diagnostics. Facts are
// separate booleans/states; the CRM derives the single display state.
// Sync health is not presence: none of this says whether anyone is working.
import { compareVersions } from "../lib/protocol.js";

export function buildFacts({ build, instanceId, session, tabIdentity, api, queue, catchUp, capabilities, leaseValid }) {
  const s = session || null;
  const minVersion = s?.config?.minExtensionVersion || null;
  return {
    extensionVersion: build.version,
    instanceId,
    env: build.env,
    paired: Boolean(s),
    outdated: Boolean(minVersion && compareVersions(build.version, minVersion) < 0),
    expectedPhoneE164: s?.account?.phoneE164 || null,
    accountName: s?.account?.displayName || null,
    userName: s?.userName || null,
    session: s ? { state: s.state, accountId: s.accountId, userId: s.userId, expiresAt: s.expiresAt } : { state: "NONE", accountId: null, userId: null, expiresAt: null },
    whatsapp: {
      state: tabIdentity?.state || "NO_TAB",
      observedPhoneE164: tabIdentity?.observedPhoneE164 || null,
      adapterError: tabIdentity?.adapterError || null,
      adapterVersion: tabIdentity?.adapterVersion || null
    },
    api: { reachable: api.reachable, lastSuccessAt: api.lastSuccessAt, lastError: api.lastError },
    queue,
    catchUp,
    lease: { valid: Boolean(leaseValid) },
    capabilities: capabilities || {}
  };
}

export function heartbeatBody(facts, { lastFlushAt, lastError }) {
  return {
    extensionVersion: facts.extensionVersion,
    whatsappState: facts.whatsapp.state,
    observedPhoneE164: facts.whatsapp.observedPhoneE164,
    queueDepth: facts.queue.events,
    mediaQueueDepth: facts.queue.media,
    lastFlushAt: lastFlushAt || null,
    lastError: lastError ? String(lastError).slice(0, 500) : null,
    catchUpComplete: facts.catchUp.complete === true,
    adapterVersion: facts.whatsapp.adapterVersion ? String(facts.whatsapp.adapterVersion).slice(0, 64) : null,
    capabilities: facts.capabilities
  };
}

// Support export: states, counts, versions and error codes only. No message
// text, no phone numbers of students, no tokens.
export function redactedDiagnostics(facts, diagnostics, selfTest) {
  return {
    generatedAt: new Date().toISOString(),
    extensionVersion: facts.extensionVersion,
    env: facts.env,
    instanceId: facts.instanceId,
    session: { state: facts.session.state, expiresAt: facts.session.expiresAt },
    account: { expectedNumberSuffix: facts.expectedPhoneE164 ? facts.expectedPhoneE164.slice(-4) : null, observedNumberSuffix: facts.whatsapp.observedPhoneE164 ? facts.whatsapp.observedPhoneE164.slice(-4) : null },
    whatsapp: { state: facts.whatsapp.state, adapterVersion: facts.whatsapp.adapterVersion, adapterError: facts.whatsapp.adapterError },
    api: facts.api,
    queue: facts.queue,
    catchUp: facts.catchUp,
    capabilities: facts.capabilities,
    adapterSelfTest: selfTest || null,
    recentIssues: (diagnostics || []).slice(-50).map((d) => ({ at: d.at, kind: d.kind, type: d.type || null, error: d.error || null }))
  };
}
