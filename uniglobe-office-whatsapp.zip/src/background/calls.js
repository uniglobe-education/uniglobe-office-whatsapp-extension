// Pin a call to one WhatsApp tab, including after an MV3 worker restart.
// A changed executor must never move status, End, or a retry to another tab.
export function createCallController({ store, rpc, getExecutor, authorize }) {
  let tail = Promise.resolve();
  const fail = (code, message) => { throw Object.assign(new Error(message), { code }); };
  const bound = (saved, message, origin) => saved?.id === message.callId && saved.origin === origin
    && saved.accountId === message.accountId && saved.userId === message.crmUserId;
  const terminal = (status) => ["ENDED", "FAILED"].includes(status);
  function run(type, message, origin) {
    const action = tail.then(async () => {
      let saved = await store.get("officeCall");
      async function update(method) {
        const result = await rpc(method, { callId: saved.id }, { tabId: saved.tabId, timeoutMs: method === "endCall" ? 5000 : 4000 });
        saved.status = result.status;
        await store.set("officeCall", saved);
        return result;
      }
      if (type !== "START_CALL") {
        if (!bound(saved, message, origin)) fail("CALL_NOT_FOUND", "Check the call in WhatsApp Web.");
        return update(type === "END_CALL" ? "endCall" : "callStatus");
      }
      if (saved?.id === message.callId) {
        if (!bound(saved, message, origin)) fail("CALL_BINDING_MISMATCH", "This call belongs to another connection.");
        return update("callStatus"); // Never redial an existing id.
      }
      if (await store.get(`officeCallUsed:${message.callId}`)) fail("CALL_NOT_FOUND", "This call has finished. Start a new call from the CRM.");
      if (saved && !terminal(saved.status)) {
        try { await update("callStatus"); }
        catch { fail("CALL_PREVIOUS_UNCERTAIN", "Check the previous call in WhatsApp Web before calling again."); }
        if (!terminal(saved.status)) fail("CALL_BUSY", "End the current office call first.");
      }
      const target = await authorize(message);
      const tabId = getExecutor();
      if (tabId === null) fail("NO_TAB", "WhatsApp Web is not open.");
      const identity = await rpc("getIdentity", {}, { tabId });
      if (identity.state !== "CONNECTED" || identity.observedPhoneE164 !== target.phoneE164) {
        fail("ACCOUNT_MISMATCH", "WhatsApp Web is signed in with another number.");
      }
      saved = { id: message.callId, tabId, origin, accountId: message.accountId, userId: message.crmUserId, status: "STARTING" };
      await store.set(`officeCallUsed:${message.callId}`, true);
      await store.set("officeCall", saved); // Persist before a possible dial.
      try {
        const result = await rpc("startCall", { chatKey: target.chatKey, callId: saved.id }, { tabId, timeoutMs: 15000 });
        saved.status = result.status;
        await store.set("officeCall", saved);
        return result;
      } catch (error) {
        if (["INVALID_CALL", "NOT_DIRECT_CHAT", "CHAT_UNAVAILABLE", "CAPABILITY_UNAVAILABLE", "CALL_BUSY"].includes(error.code)) {
          saved.status = "FAILED";
          await store.set("officeCall", saved);
        } else if (!["NO_TAB", "PAGE_TIMEOUT"].includes(error.code)) {
          fail("CALL_UNCERTAIN", "Check the call in WhatsApp Web before trying again.");
        }
        throw error;
      }
    });
    tail = action.catch(() => {});
    return action;
  }
  return { run };
}
