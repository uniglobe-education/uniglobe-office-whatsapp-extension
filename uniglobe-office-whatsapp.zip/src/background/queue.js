// Media transfer queue, separate from (and bounded independently of) the
// event queue. A job is created only after the message event itself was
// stored by the server, so the attachment always has a message to attach to.
// Bytes are pulled from the local WhatsApp Web client in chunks, uploaded to a
// server-issued signed URL on the allowed storage host, then confirmed.
// Nothing is kept locally after upload; failures are reported, not hidden.
import { computeBackoff } from "../lib/backoff.js";
import { isAllowedUrl } from "../lib/origins.js";

export const MEDIA_QUEUE_CAPACITY = 500;
export const MEDIA_MAX_ATTEMPTS = 6;
const CHUNK = 512 * 1024;

function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
  return out;
}

export function createMediaQueue({ table, api, rpc, mediaOrigins, maxBytes = () => 32 * 1024 * 1024, fetchImpl = (...a) => fetch(...a), diagnostics, now = Date.now, random = Math.random }) {
  const stats = { droppedFull: 0 };

  async function enqueue(partition, event) {
    const media = event.message?.media;
    if (!media) return false;
    const id = `${partition}|${event.providerMessageId}`;
    if (await table.get(id)) return true;
    if ((await table.count()) >= MEDIA_QUEUE_CAPACITY) {
      stats.droppedFull += 1;
      await diagnostics?.add({ kind: "MEDIA_QUEUE_FULL", eventKey: event.eventKey });
      return false;
    }
    await table.put({
      id, partition, providerMessageId: event.providerMessageId, chatKey: event.chatKey,
      fileName: media.fileName || null, mimeType: media.mimeType || null, size: media.size ?? null,
      downloadable: media.downloadable !== false, unavailableReason: media.unavailableReason || null,
      attempts: 0, nextAttemptAt: 0, createdAt: now()
    });
    return true;
  }

  async function fail(job, uploadId, reason, message) {
    if (uploadId) await api.request(`/office-extension/media/${encodeURIComponent(uploadId)}/fail`, { body: { reason, message: message ? String(message).slice(0, 300) : null } });
    await table.delete(job.id);
  }

  async function transfer(job) {
    const start = await api.request("/office-extension/media/uploads", {
      body: { providerMessageId: job.providerMessageId, mimeType: job.mimeType, size: job.size, fileName: job.fileName }
    });
    // Any status reply (ALREADY_STORED, UNAVAILABLE) means nothing to upload.
    if (start.status) { await table.delete(job.id); return start.status; }
    const uploadId = start.uploadId;
    if (!job.downloadable) { await fail(job, uploadId, "UNAVAILABLE", job.unavailableReason); return "UNAVAILABLE"; }
    if (!isAllowedUrl(start.uploadUrl, mediaOrigins)) throw new Error("Upload URL is not on an allowed storage host");
    const fetched = await rpc("fetchMedia", { providerMessageId: job.providerMessageId, maxBytes: maxBytes() });
    if (fetched.unavailable) {
      if (fetched.unavailable === "TOO_LARGE") { await fail(job, uploadId, "TOO_LARGE"); return "TOO_LARGE"; }
      if (fetched.unavailable === "DOWNLOAD_FAILED" && job.attempts + 1 < MEDIA_MAX_ATTEMPTS) throw new Error(fetched.message || "download failed");
      await fail(job, uploadId, fetched.unavailable === "DOWNLOAD_FAILED" ? "DOWNLOAD_FAILED" : "UNAVAILABLE", fetched.unavailable);
      return fetched.unavailable;
    }
    try {
      const parts = [];
      let offset = 0;
      for (;;) {
        const piece = await rpc("readMediaChunk", { token: fetched.token, offset, length: CHUNK });
        const bytes = b64ToBytes(piece.chunk || "");
        parts.push(bytes);
        offset += bytes.length;
        if (piece.done || !bytes.length) break;
        if (offset > maxBytes()) throw new Error("media exceeded size limit");
      }
      const blob = new Blob(parts, { type: fetched.mimeType || job.mimeType || "application/octet-stream" });
      const put = await fetchImpl(start.uploadUrl, { method: start.method || "PUT", headers: start.headers || { "content-type": blob.type }, body: blob, credentials: "omit" });
      if (!put.ok) throw new Error(`storage upload returned HTTP ${put.status}`);
      await api.request(`/office-extension/media/${encodeURIComponent(uploadId)}/complete`, { body: { size: blob.size } });
      await table.delete(job.id);
      return "READY";
    } finally {
      rpc("releaseMedia", { token: fetched.token }).catch(() => {});
    }
  }

  // Processes due jobs of the current partition, one at a time.
  async function process(partition, { max = 5 } = {}) {
    const due = (await table.all())
      .filter((job) => job.partition === partition && job.nextAttemptAt <= now())
      .sort((a, b) => a.createdAt - b.createdAt)
      .slice(0, max);
    const results = [];
    for (const job of due) {
      try {
        results.push(await transfer(job));
      } catch (error) {
        const attempts = job.attempts + 1;
        if (attempts >= MEDIA_MAX_ATTEMPTS) {
          await diagnostics?.add({ kind: "MEDIA_FAILED", eventKey: `msg:${job.providerMessageId}`, error: String(error.message || "").slice(0, 200) });
          await table.delete(job.id);
        } else {
          await table.put({ ...job, attempts, nextAttemptAt: now() + computeBackoff(attempts, { random, baseMs: 10000 }) });
        }
        results.push("RETRY");
        if (error.network) break;
      }
    }
    return results;
  }

  async function depth() {
    return table.count();
  }

  return { enqueue, process, depth, stats };
}
