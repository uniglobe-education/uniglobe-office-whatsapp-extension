// CRM → WhatsApp command execution (protocol.md §Commands).
//
// The one rule: a command is never sent twice. Order of operations:
//   1. check expiry, capability and the signed-in number (nothing sent yet)
//   2. generate the WhatsApp message id without sending (prepareSend)
//   3. journal { commandId, providerMessageId, state: INTENT }
//   4. report EXECUTING to the server (only the live lease holder is accepted)
//   5. journal SENDING, re-check the number, send
//   6. journal the outcome and report it (retried until the server has it)
// After a crash, SENDING entries are resolved by looking the message id up in
// WhatsApp Web (found → PROVIDER_ACCEPTED, otherwise OUTCOME_UNKNOWN). They
// are never re-sent; the counselor decides after checking WhatsApp.
import { ERROR_CODES } from "../lib/protocol.js";
import { isAllowedUrl } from "../lib/origins.js";
import { ApiError } from "./api.js";

const UNCERTAIN_AFTER_MS = 10 * 60 * 1000;
const CHUNK = 384 * 1024; // raw bytes per staged chunk (base64 ~512KB)

export class AdapterError extends Error {
  constructor(code, message) {
    super(message || code);
    this.code = code;
  }
}

// Wraps a bridge RPC ({ ok, result, error }) into throw-on-error.
export function wrapRpc(rawRpc) {
  return async function rpc(method, params, options) {
    const reply = await rawRpc(method, params, options);
    if (!reply || reply.ok !== true) throw new AdapterError(reply?.error?.code || "NO_TAB", reply?.error?.message || "WhatsApp Web did not respond");
    return reply.result;
  };
}

function capabilityFor(command) {
  if (command.operation === "SEND_TEXT") return command.payload?.quotedProviderMessageId ? "sendQuotedReply" : "sendText";
  if (command.operation === "SEND_MEDIA") return "sendMedia";
  if (command.operation === "REACT") return "react";
  if (command.operation === "MARK_READ") return "markRead";
  return null;
}

function bytesToB64(bytes) {
  let out = "";
  for (let i = 0; i < bytes.length; i += 0x8000) out += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(out);
}

export function createCommandExecutor({ api, journal, rpc, expectedPhone, capabilities, mediaOrigins = [], maxMediaBytes = () => 32 * 1024 * 1024, fetchImpl = (...a) => fetch(...a), now = Date.now, log = () => {} }) {
  async function report(commandId, body) {
    return api.request(`/office-extension/commands/${encodeURIComponent(commandId)}/result`, { body });
  }

  // Reports a final outcome; the journal keeps it until the server confirms.
  async function finish(entry, result) {
    const updated = await journal.update(entry.commandId, { state: `DONE_${result.state}`, result, reported: false });
    try {
      await report(entry.commandId, { leaseToken: entry.leaseToken, ...result });
      await journal.update(entry.commandId, { reported: true });
    } catch (error) {
      if (error instanceof ApiError && !error.network) {
        // The server has decided (lease lost / command closed); keep the entry
        // for echo tagging but stop retrying.
        await journal.update(entry.commandId, { reported: true, reportError: error.code || error.message });
      }
      // Network: stays unreported; reconcile() retries.
    }
    return updated;
  }

  async function checkIdentity() {
    const identity = await rpc("getIdentity", {});
    if (identity?.state !== "CONNECTED") return { ok: false, code: "WHATSAPP_NOT_CONNECTED" };
    if (!expectedPhone() || identity.observedPhoneE164 !== expectedPhone()) return { ok: false, code: ERROR_CODES.ACCOUNT_MISMATCH };
    return { ok: true, identity };
  }

  async function rejectBeforeStart(command, errorCode, errorMessage) {
    // Nothing was sent; FAILED is the truthful outcome.
    try {
      await report(command.id, { state: "FAILED", leaseToken: command.leaseToken, errorCode, errorMessage: errorMessage || null });
    } catch { /* lease expiry returns it to the queue server-side */ }
    return { commandId: command.id, outcome: "FAILED", errorCode };
  }

  async function downloadMedia(media) {
    if (!media?.url || !isAllowedUrl(media.url, mediaOrigins)) throw new AdapterError("NOT_SENT_MEDIA_HOST", "Media URL is not on an allowed storage host");
    const response = await fetchImpl(media.url, { credentials: "omit", cache: "no-store" });
    if (!response.ok) throw new AdapterError("NOT_SENT_MEDIA_DOWNLOAD", `media download HTTP ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.length > maxMediaBytes()) throw new AdapterError("NOT_SENT_TOO_LARGE", "media too large");
    return bytes;
  }

  async function execute(command) {
    if (await journal.get(command.id)) return { commandId: command.id, outcome: "ALREADY_JOURNALED" };
    if (!command.expiresAt || Date.parse(command.expiresAt) <= now()) return rejectBeforeStart(command, "COMMAND_EXPIRED");
    const capability = capabilityFor(command);
    if (!capability) return rejectBeforeStart(command, "UNSUPPORTED_OPERATION");
    if (!capabilities()?.[capability]) return rejectBeforeStart(command, ERROR_CODES.CAPABILITY_UNAVAILABLE, `${capability} is not available in this WhatsApp Web version`);

    let staged = null;
    let prepared = null;
    try {
      const check = await checkIdentity();
      if (!check.ok) return rejectBeforeStart(command, check.code);
      if (command.operation === "SEND_TEXT") {
        prepared = await rpc("prepareSend", { chatKey: command.chatKey });
      } else if (command.operation === "SEND_MEDIA") {
        const bytes = await downloadMedia(command.payload?.media);
        staged = `s${command.id}`;
        for (let offset = 0; offset < bytes.length || offset === 0; offset += CHUNK) {
          await rpc("stageMedia", { token: staged, chunk: bytesToB64(bytes.subarray(offset, offset + CHUNK)), mimeType: command.payload.media.mimeType });
          if (bytes.length === 0) break;
        }
      }
    } catch (error) {
      return rejectBeforeStart(command, error.code && /^NOT_SENT|CAPABILITY|NO_TAB|PAGE_TIMEOUT/.test(error.code) ? error.code : "NOT_SENT_PREPARE_FAILED", error.message);
    }

    const entry = {
      commandId: command.id,
      leaseToken: command.leaseToken,
      operation: command.operation,
      chatKey: command.chatKey,
      providerMessageId: prepared?.providerMessageId || null,
      state: "INTENT",
      reported: false,
      createdAt: now()
    };
    await journal.put(entry);

    try {
      await report(command.id, { state: "EXECUTING", leaseToken: command.leaseToken, providerMessageId: entry.providerMessageId });
    } catch (error) {
      // Server did not confirm the lease: do not send. The journal entry is
      // removed; nothing left WhatsApp Web.
      await journal.delete(command.id);
      return { commandId: command.id, outcome: "NOT_STARTED", errorCode: error.code || "EXECUTING_NOT_CONFIRMED" };
    }
    await journal.update(command.id, { state: "SENDING" });

    let sendResult;
    try {
      // Last-moment check: the signed-in number may have changed.
      const check = await checkIdentity();
      if (!check.ok) throw new AdapterError(`NOT_SENT_${check.code}`, "Signed-in number changed before sending");
      if (command.operation === "SEND_TEXT") {
        sendResult = await rpc("commitSend", { token: prepared.token, text: command.payload?.text, quotedProviderMessageId: command.payload?.quotedProviderMessageId || null });
      } else if (command.operation === "SEND_MEDIA") {
        const media = command.payload.media;
        sendResult = await rpc("sendMedia", { token: staged, chatKey: command.chatKey, mimeType: media.mimeType, fileName: media.fileName, kind: media.kind, asVoice: media.asVoice === true, caption: command.payload.caption || null }, { timeoutMs: 180000 });
      } else if (command.operation === "REACT") {
        sendResult = await rpc("react", { targetProviderMessageId: command.payload?.targetProviderMessageId, emoji: command.payload?.emoji || "" });
      } else {
        sendResult = await rpc("markRead", { chatKey: command.chatKey });
      }
    } catch (error) {
      const code = error.code || "SEND_UNCERTAIN";
      if (/^NOT_SENT/.test(code)) {
        await finish(entry, { state: "FAILED", errorCode: code.slice(0, 80), errorMessage: error.message ? String(error.message).slice(0, 300) : null });
        return { commandId: command.id, outcome: "FAILED", errorCode: code };
      }
      return resolveUncertain({ ...entry, state: "SENDING" }, code);
    }
    const providerMessageId = sendResult?.providerMessageId || entry.providerMessageId || null;
    if (providerMessageId !== entry.providerMessageId) await journal.update(command.id, { providerMessageId });
    await finish({ ...entry, providerMessageId }, { state: "PROVIDER_ACCEPTED", providerMessageId });
    return { commandId: command.id, outcome: "PROVIDER_ACCEPTED", providerMessageId };
  }

  // The send may or may not have happened. Look, never resend.
  async function resolveUncertain(entry, reason) {
    if (entry.providerMessageId) {
      try {
        const found = await rpc("messageExists", { providerMessageId: entry.providerMessageId });
        if (found?.exists) {
          await finish(entry, { state: "PROVIDER_ACCEPTED", providerMessageId: entry.providerMessageId });
          return { commandId: entry.commandId, outcome: "PROVIDER_ACCEPTED", providerMessageId: entry.providerMessageId, reconciled: true };
        }
      } catch (error) {
        // Page unavailable: decide later unless the entry is old.
        if (now() - entry.createdAt < UNCERTAIN_AFTER_MS) return { commandId: entry.commandId, outcome: "PENDING_RECONCILE" };
      }
    }
    await finish(entry, { state: "OUTCOME_UNKNOWN", providerMessageId: entry.providerMessageId, errorCode: String(reason || "SEND_UNCERTAIN").slice(0, 80), errorMessage: "Check WhatsApp before retrying" });
    return { commandId: entry.commandId, outcome: "OUTCOME_UNKNOWN" };
  }

  // Runs at startup and periodically. Resolves interrupted executions.
  async function reconcile() {
    const results = [];
    for (const entry of await journal.all()) {
      if (entry.reported) continue;
      if (entry.state === "INTENT") {
        // EXECUTING was never confirmed, so the send step never ran.
        try { await report(entry.commandId, { state: "FAILED", leaseToken: entry.leaseToken, errorCode: "NOT_SENT_INTERRUPTED", errorMessage: "Extension restarted before sending" }); } catch { /* lease expiry handles it */ }
        await journal.delete(entry.commandId);
        results.push({ commandId: entry.commandId, outcome: "NOT_SENT" });
      } else if (entry.state === "SENDING") {
        results.push(await resolveUncertain(entry, "INTERRUPTED_DURING_SEND"));
      } else if (entry.result) {
        await finish(entry, entry.result);
        results.push({ commandId: entry.commandId, outcome: "REPORTED" });
      }
    }
    await journal.prune();
    return results;
  }

  async function claimAndRun({ max = 3 } = {}) {
    const { commands = [] } = await api.request("/office-extension/commands/claim", { body: { max } });
    const results = [];
    for (const command of commands) {
      try {
        results.push(await execute(command));
      } catch (error) {
        log("command execution error", error.message);
        results.push({ commandId: command.id, outcome: "ERROR" });
      }
    }
    return { claimed: commands.length, results };
  }

  // Marks observed outgoing messages that this extension sent for a command.
  async function tagEvent(event) {
    if (!event.providerMessageId || event.type === "CONTACT_MAPPING") return event;
    const entry = await journal.findByProviderMessageId(event.providerMessageId);
    if (!entry) return event;
    const tagged = { ...event, clientCommandId: entry.commandId };
    if (event.type === "MESSAGE_UPSERT" && event.direction === "OUTBOUND") tagged.senderAttribution = "CRM_COMMAND";
    return tagged;
  }

  return { execute, reconcile, claimAndRun, tagEvent };
}
