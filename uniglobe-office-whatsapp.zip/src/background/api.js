// HTTPS client for the CRM's /office-extension routes. The access token is
// held by the service worker only; content scripts and the page never see it.
import { ERROR_CODES } from "../lib/protocol.js";

export class ApiError extends Error {
  constructor(message, { status = 0, code = null, network = false } = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.network = network;
  }
}

// Codes after which the session can never be used again.
export const FATAL_SESSION_CODES = new Set([
  ERROR_CODES.SESSION_REVOKED,
  ERROR_CODES.SESSION_EXPIRED,
  ERROR_CODES.SESSION_INVALID,
  ERROR_CODES.ACCOUNT_DISABLED,
  ERROR_CODES.NOT_A_MEMBER
]);

export function createApiClient({ getBase, getAccessToken, fetchImpl = (...args) => fetch(...args), onReachability = () => {}, timeoutMs = 30000 }) {
  async function request(path, { method = "POST", body, auth = true } = {}) {
    const base = getBase();
    if (!base) throw new ApiError("Not paired", { code: ERROR_CODES.SESSION_INVALID });
    const headers = { "content-type": "application/json" };
    if (auth) {
      const token = await getAccessToken();
      if (!token) throw new ApiError("No session", { code: ERROR_CODES.SESSION_INVALID, status: 401 });
      headers.authorization = `Bearer ${token}`;
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let response;
    try {
      response = await fetchImpl(`${base}${path}`, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
        credentials: "omit",
        cache: "no-store"
      });
    } catch (error) {
      onReachability(false, error.message || "network error");
      throw new ApiError("CRM API unreachable", { network: true });
    } finally {
      clearTimeout(timer);
    }
    const payload = await response.json().catch(() => ({}));
    if (response.status >= 500) onReachability(false, `HTTP ${response.status}`);
    else onReachability(true, null);
    if (!response.ok) {
      throw new ApiError(payload.error || `HTTP ${response.status}`, { status: response.status, code: payload.details?.code || payload.code || null });
    }
    return payload;
  }
  return { request };
}
