// chrome.runtime.onMessageExternal handler for the CRM web app.
// Chrome already restricts senders to externally_connectable.matches; the
// origin is checked again here against the exact build allowlist.
import { isAllowedOrigin, originOf } from "../lib/origins.js";

export const EXTERNAL_TYPES = ["PING", "STATUS", "PAIR", "ENSURE_WHATSAPP_TAB", "OPEN_CHAT", "START_CALL", "CALL_STATUS", "END_CALL", "LOGOUT"];

export function senderOrigin(sender) {
  return sender?.origin || originOf(sender?.url);
}

export function createExternalHandler({ allowedOrigins, handlers }) {
  return async function handle(message, sender) {
    const origin = senderOrigin(sender);
    if (!isAllowedOrigin(origin, allowedOrigins)) return { ok: false, error: "ORIGIN_NOT_ALLOWED" };
    if (!message || typeof message !== "object" || !EXTERNAL_TYPES.includes(message.type)) return { ok: false, error: "UNKNOWN_MESSAGE" };
    const handler = handlers[message.type];
    if (!handler) return { ok: false, error: "UNKNOWN_MESSAGE" };
    try {
      return await handler(message, { origin });
    } catch (error) {
      return { ok: false, error: error.code || "FAILED", message: String(error.message || "").slice(0, 200) };
    }
  };
}
