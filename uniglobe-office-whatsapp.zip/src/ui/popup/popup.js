// Popup: shows the connection facts and offers a few safe actions.
const $ = (id) => document.getElementById(id);

function summarize(f) {
  if (!f.paired) return ["warn", "Not connected. Open the UniGlobe CRM in this browser profile and sign in."];
  if (f.outdated) return ["err", "This extension version is too old for the CRM. Update it."];
  if (["REVOKED", "EXPIRED"].includes(f.session.state)) return ["warn", "Session ended. Sign in to the CRM again."];
  if (f.session.state === "MISMATCH") return ["err", `Wrong WhatsApp number: expected ${f.expectedPhoneE164 || "?"}, seeing ${f.whatsapp.observedPhoneE164 || "?"}. Sync and sending are paused.`];
  if (f.whatsapp.state === "NO_TAB") return ["warn", "WhatsApp Web is not open."];
  if (f.whatsapp.state === "LOGGED_OUT") return ["warn", `Link ${f.expectedPhoneE164 || "your office number"} in WhatsApp Web.`];
  if (f.whatsapp.state === "ADAPTER_ERROR") return ["err", "WhatsApp Web changed and cannot be read. Syncing is stopped."];
  if (f.api.reachable === false) return ["warn", "CRM not reachable. Messages are kept on this computer and sent when it returns."];
  if (f.session.state !== "ACTIVE") return ["warn", "Connecting…"];
  if (!f.catchUp.complete) return ["ok", `Connected. Catching up${f.catchUp.pendingChats ? ` (${f.catchUp.pendingChats} chats left)` : ""}…`];
  return ["ok", "Connected and syncing."];
}

function row(label, value) {
  const dt = document.createElement("dt");
  dt.textContent = label;
  const dd = document.createElement("dd");
  dd.textContent = value ?? "—";
  return [dt, dd];
}

function when(iso) {
  return iso ? new Date(iso).toLocaleString() : "never";
}

async function load() {
  const reply = await chrome.runtime.sendMessage({ type: "GET_FACTS" }).catch(() => null);
  const f = reply?.facts;
  if (!f) { $("summary").textContent = "Extension is starting…"; return; }
  $("version").textContent = `v${f.extensionVersion} (${f.env})`;
  const [tone, text] = summarize(f);
  $("summary").className = `card ${tone}`;
  $("summary").textContent = text;
  const list = $("facts");
  list.textContent = "";
  [
    row("Staff", f.userName),
    row("Office number", f.expectedPhoneE164),
    row("WhatsApp shows", f.whatsapp.observedPhoneE164 || f.whatsapp.state),
    row("Session", f.session.state),
    row("CRM server", f.api.reachable === null ? "not checked yet" : f.api.reachable ? "reachable" : "unreachable"),
    row("Last sync", when(f.api.lastSuccessAt)),
    row("Waiting to send", `${f.queue.events} messages, ${f.queue.media} files`),
    row("On hold", f.queue.quarantined ? `${f.queue.quarantined} from an earlier sign-in` : "none")
  ].flat().forEach((node) => list.appendChild(node));
}

$("open-whatsapp").addEventListener("click", () => chrome.runtime.sendMessage({ type: "OPEN_WHATSAPP" }));
$("open-crm").addEventListener("click", () => chrome.runtime.sendMessage({ type: "OPEN_CRM" }));
$("retry").addEventListener("click", async () => { await chrome.runtime.sendMessage({ type: "RETRY_SYNC" }); load(); });
$("export").addEventListener("click", async () => {
  const reply = await chrome.runtime.sendMessage({ type: "EXPORT_DIAGNOSTICS" });
  if (!reply?.diagnostics) return;
  const blob = new Blob([JSON.stringify(reply.diagnostics, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `uniglobe-office-whatsapp-diagnostics-${Date.now()}.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 5000);
});

load();
setInterval(load, 5000);
