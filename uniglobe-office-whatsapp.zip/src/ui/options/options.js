import { BUILD } from "../../lib/build-config.js";

const env = document.getElementById("env");
[["Build", `${BUILD.env} v${BUILD.version}`], ["CRM", BUILD.crmOrigins.join(", ")], ["API", BUILD.apiBases.join(", ")], ["File storage", BUILD.mediaOrigins.join(", ")], ["Extension ID", chrome.runtime.id]]
  .forEach(([label, value]) => {
    const dt = document.createElement("dt");
    dt.textContent = label;
    const dd = document.createElement("dd");
    dd.textContent = value;
    env.append(dt, dd);
  });

async function refresh() {
  const reply = await chrome.runtime.sendMessage({ type: "EXPORT_DIAGNOSTICS" }).catch(() => null);
  document.getElementById("diag").textContent = reply?.diagnostics ? JSON.stringify(reply.diagnostics, null, 2) : "Extension is starting…";
}
document.getElementById("refresh").addEventListener("click", refresh);
refresh();
